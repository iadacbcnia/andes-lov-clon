import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Star, Trash2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface Review {
  id: string;
  user_id: string | null;
  user_name: string | null;
  rating: number;
  comment: string | null;
  created_at: string;
}

interface PlaceReviewsProps {
  placeId: string;
  placeName: string;
}

export const PlaceReviews = ({ placeId, placeName }: PlaceReviewsProps) => {
  const [reviews, setReviews] = useState<Review[]>([]);
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [user, setUser] = useState<any>(null);
  const { toast } = useToast();
  const navigate = useNavigate();

  useEffect(() => {
    loadReviews();
    checkAuth();
  }, [placeId]);

  const checkAuth = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    setUser(user);
    
    if (user) {
      const { data: roleData } = await supabase
        .from('user_roles')
        .select('role')
        .eq('user_id', user.id)
        .eq('role', 'admin')
        .maybeSingle();
      
      setIsAdmin(!!roleData);
    }
  };

  const loadReviews = async () => {
    const { data, error } = await supabase
      .from('reviews')
      .select('*')
      .eq('place_id', placeId)
      .order('created_at', { ascending: false });

    if (!error && data) {
      setReviews(data);
    }
  };

  const calculateAverage = () => {
    if (reviews.length === 0) return 0;
    const sum = reviews.reduce((acc, review) => acc + review.rating, 0);
    return (sum / reviews.length).toFixed(1);
  };

  const handleSubmit = async () => {
    if (!user) {
      toast({
        title: "Debes iniciar sesión",
        description: "Inicia sesión para dejar una valoración",
        variant: "destructive"
      });
      navigate('/auth');
      return;
    }

    if (rating === 0) {
      toast({
        title: "Selecciona una puntuación",
        description: "Por favor selecciona al menos 1 estrella",
        variant: "destructive"
      });
      return;
    }

    setIsSubmitting(true);

    const { error } = await supabase
      .from('reviews')
      .insert({
        place_id: placeId,
        user_id: user.id,
        user_name: user.email?.split('@')[0] || 'Usuario',
        rating,
        comment: comment || null
      });

    if (error) {
      toast({
        title: "Error",
        description: "No se pudo guardar tu valoración",
        variant: "destructive"
      });
    } else {
      toast({
        title: "¡Gracias!",
        description: "Tu valoración ha sido publicada"
      });
      setRating(0);
      setComment('');
      loadReviews();
    }

    setIsSubmitting(false);
  };

  const handleDelete = async (reviewId: string) => {
    const { error } = await supabase
      .from('reviews')
      .delete()
      .eq('id', reviewId);

    if (error) {
      toast({
        title: "Error",
        description: "No se pudo eliminar la valoración",
        variant: "destructive"
      });
    } else {
      toast({
        title: "Eliminado",
        description: "La valoración ha sido eliminada"
      });
      loadReviews();
    }
  };

  const renderStars = (currentRating: number, interactive: boolean = false) => {
    return (
      <div className="flex gap-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <Star
            key={star}
            className={`w-6 h-6 ${interactive ? 'cursor-pointer' : ''} ${
              star <= currentRating
                ? 'fill-yellow-400 text-yellow-400'
                : 'text-gray-300'
            }`}
            onClick={() => interactive && setRating(star)}
          />
        ))}
      </div>
    );
  };

  const average = calculateAverage();

  return (
    <div className="w-full max-w-4xl mx-auto p-3 sm:p-6 space-y-4 sm:space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-lg sm:text-2xl break-words">Valoraciones - {placeName}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center gap-3 sm:gap-4 p-4 sm:p-6 bg-muted rounded-lg">
            <div className="text-4xl sm:text-6xl font-bold">{average}</div>
            <div className="flex gap-1">
              {renderStars(Math.round(Number(average)))}
            </div>
            <div className="text-sm sm:text-base text-muted-foreground">
              {reviews.length} {reviews.length === 1 ? 'valoración' : 'valoraciones'}
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base sm:text-xl">Deja tu opinión</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 sm:space-y-4">
          <div>
            <p className="text-sm font-medium mb-2">Tu puntuación</p>
            {renderStars(rating, true)}
          </div>
          <Textarea
            placeholder="Escribe tu opinión (opcional)"
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            rows={4}
          />
          <Button onClick={handleSubmit} disabled={isSubmitting}>
            {isSubmitting ? 'Enviando...' : 'Publicar valoración'}
          </Button>
        </CardContent>
      </Card>

      <div className="space-y-3 sm:space-y-4">
        <h3 className="text-lg sm:text-xl font-semibold">Todas las opiniones</h3>
        {reviews.length === 0 ? (
          <Card>
            <CardContent className="p-6 text-center text-muted-foreground">
              Aún no hay valoraciones. ¡Sé el primero en opinar!
            </CardContent>
          </Card>
        ) : (
          reviews.map((review) => (
            <Card key={review.id}>
              <CardContent className="p-4 sm:p-6">
                <div className="flex justify-between items-start gap-2">
                  <div className="flex-1 min-w-0">
                    <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-3 mb-2">
                      <span className="font-semibold text-sm sm:text-base break-words">{review.user_name || 'Usuario'}</span>
                      {renderStars(review.rating)}
                    </div>
                    {review.comment && (
                      <p className="text-sm text-muted-foreground mt-2 break-words">{review.comment}</p>
                    )}
                    <p className="text-xs text-muted-foreground mt-2">
                      {new Date(review.created_at).toLocaleDateString('es-AR', {
                        year: 'numeric',
                        month: 'long',
                        day: 'numeric'
                      })}
                    </p>
                  </div>
                  {isAdmin && (
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleDelete(review.id)}
                      className="text-destructive hover:text-destructive flex-shrink-0"
                    >
                      <Trash2 className="w-4 h-4 sm:w-5 sm:h-5" />
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
};
