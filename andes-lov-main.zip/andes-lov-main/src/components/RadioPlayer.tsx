import { useState, useRef, useEffect } from "react";
import { Play, Pause, Volume2, VolumeX } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import logoFmParaiso from "@/assets/logo-fm-paraiso-42.png";

export const RadioPlayer = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [volume, setVolume] = useState([70]);
  const [isLoading, setIsLoading] = useState(false);
  const audioRef = useRef<HTMLAudioElement>(null);

  const streamUrl = "https://streaming6.locucionar.com:24140/stream";

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const handleLoadStart = () => {
      console.log('Radio: Loading started');
      setIsLoading(true);
    };
    
    const handleCanPlay = () => {
      console.log('Radio: Can play');
      setIsLoading(false);
    };
    
    const handleError = (e: Event) => {
      console.error('Radio: Error occurred', e);
      setIsLoading(false);
      setIsPlaying(false);
    };

    const handleWaiting = () => {
      console.log('Radio: Waiting for data');
      setIsLoading(true);
    };

    const handlePlaying = () => {
      console.log('Radio: Started playing');
      setIsLoading(false);
    };

    audio.addEventListener('loadstart', handleLoadStart);
    audio.addEventListener('canplay', handleCanPlay);
    audio.addEventListener('error', handleError);
    audio.addEventListener('waiting', handleWaiting);
    audio.addEventListener('playing', handlePlaying);

    return () => {
      audio.removeEventListener('loadstart', handleLoadStart);
      audio.removeEventListener('canplay', handleCanPlay);
      audio.removeEventListener('error', handleError);
      audio.removeEventListener('waiting', handleWaiting);
      audio.removeEventListener('playing', handlePlaying);
    };
  }, []);

  const togglePlay = async () => {
    const audio = audioRef.current;
    if (!audio) return;

    console.log('Radio: Toggle play clicked', { isPlaying, isLoading });

    try {
      if (isPlaying) {
        console.log('Radio: Pausing');
        audio.pause();
        setIsPlaying(false);
        setIsLoading(false);
      } else {
        console.log('Radio: Starting play');
        setIsLoading(true);
        
        // Force reload the stream to get fresh data
        audio.load();
        
        const playPromise = audio.play();
        if (playPromise !== undefined) {
          await playPromise;
          console.log('Radio: Play promise resolved');
          setIsPlaying(true);
          setIsLoading(false);
        }
      }
    } catch (error) {
      console.error('Error playing audio:', error);
      setIsPlaying(false);
      setIsLoading(false);
    }
  };

  const toggleMute = () => {
    const audio = audioRef.current;
    if (!audio) return;

    audio.muted = !audio.muted;
    setIsMuted(!isMuted);
  };

  const handleVolumeChange = (value: number[]) => {
    const audio = audioRef.current;
    if (!audio) return;

    const newVolume = value[0];
    setVolume(value);
    audio.volume = newVolume / 100;
  };

  return (
    <Card className="w-full max-w-xs bg-gradient-to-br from-primary/5 to-accent/5 border-0 shadow-mountain">
      <CardContent className="p-3">
        <div className="flex items-center space-x-3">
          {/* Logo más pequeño */}
          <div className="flex-shrink-0">
            <img 
              src={logoFmParaiso} 
              alt="FM Paraíso 42" 
              className="w-12 h-12 rounded-lg object-cover shadow-lg"
            />
          </div>

          {/* Controls compactos */}
          <div className="flex-1 space-y-2">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-semibold text-xs text-foreground">FM Paraíso 42</h3>
                <p className="text-[10px] text-muted-foreground">En vivo</p>
              </div>
              
              {/* Play/Pause Button compacto */}
              <Button
                onClick={togglePlay}
                disabled={isLoading}
                size="sm"
                className="rounded-full w-9 h-9 bg-primary hover:bg-primary/90 shadow-lg"
              >
                {isLoading ? (
                  <div className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin" />
                ) : isPlaying ? (
                  <Pause className="w-4 h-4" />
                ) : (
                  <Play className="w-4 h-4 ml-0.5" />
                )}
              </Button>
            </div>

            {/* Volume Control compacto */}
            <div className="flex items-center space-x-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={toggleMute}
                className="p-0.5 h-5 w-5"
              >
                {isMuted ? (
                  <VolumeX className="w-3 h-3" />
                ) : (
                  <Volume2 className="w-3 h-3" />
                )}
              </Button>
              <Slider
                value={volume}
                onValueChange={handleVolumeChange}
                max={100}
                step={1}
                className="flex-1 h-1"
              />
            </div>
          </div>
        </div>

        {/* Hidden audio element */}
        <audio
          ref={audioRef}
          src={streamUrl}
          preload="none"
          className="hidden"
        />
      </CardContent>
    </Card>
  );
};