// Sistema de límites de uso para optimizar consumo de créditos
// Los administradores pueden desactivar límites usando el código especial

interface UsageLimits {
  chatAndes: number;
  storybook: number;
  tripPlanner: number;
}

const LIMITS: UsageLimits = {
  chatAndes: 15,
  storybook: 1,
  tripPlanner: 3,
};

const STORAGE_KEY = 'andes_usage';
const ADMIN_MODE_KEY = 'andes_admin_mode';

interface UsageData {
  chatAndes: number;
  storybook: number;
  tripPlanner: number;
  resetDate: string;
}

export const getUsageData = (): UsageData => {
  const today = new Date().toDateString();
  const stored = localStorage.getItem(STORAGE_KEY);
  
  if (!stored) {
    const initialData = {
      chatAndes: 0,
      storybook: 0,
      tripPlanner: 0,
      resetDate: today,
    };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(initialData));
    return initialData;
  }
  
  const data: UsageData = JSON.parse(stored);
  
  // Resetear si cambió el día
  if (data.resetDate !== today) {
    const resetData = {
      chatAndes: 0,
      storybook: 0,
      tripPlanner: 0,
      resetDate: today,
    };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(resetData));
    return resetData;
  }
  
  return data;
};

export const incrementUsage = (feature: keyof UsageLimits): void => {
  if (isAdminMode()) return; // Administrador no tiene límites
  
  const data = getUsageData();
  data[feature]++;
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
};

export const canUseFeature = (feature: keyof UsageLimits): boolean => {
  if (isAdminMode()) return true; // Administrador sin límites
  
  const data = getUsageData();
  return data[feature] < LIMITS[feature];
};

export const getRemainingUses = (feature: keyof UsageLimits): number => {
  if (isAdminMode()) return 999; // Mostrar "ilimitado" para admin
  
  const data = getUsageData();
  return Math.max(0, LIMITS[feature] - data[feature]);
};

export const getLimit = (feature: keyof UsageLimits): number => {
  return LIMITS[feature];
};

// Modo administrador
export const isAdminMode = (): boolean => {
  return localStorage.getItem(ADMIN_MODE_KEY) === 'true';
};

export const enableAdminMode = (code: string): boolean => {
  // Código especial para desarrollador (cámbialo por uno seguro)
  if (code === 'comarca2025') {
    localStorage.setItem(ADMIN_MODE_KEY, 'true');
    return true;
  }
  return false;
};

export const disableAdminMode = (): void => {
  localStorage.removeItem(ADMIN_MODE_KEY);
};
