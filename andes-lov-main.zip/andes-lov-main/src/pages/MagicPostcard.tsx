import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Sparkles, Upload, MapPin, LogOut, Image as ImageIcon } from "lucide-react";
import { VoiceInput } from "@/components/VoiceInput";

export default function MagicPostcard() {
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [checkingAuth, setCheckingAuth] = useState(true);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [prompt, setPrompt] = useState("");
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [remaining, setRemaining] = useState<number | null>(null);
  const [location, setLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [myPostcards, setMyPostcards] = useState<any[]>([]);
  const { toast } = useToast();
  const navigate = useNavigate();

  useEffect(() => {
    // Setup auth listener first
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        if (session?.user) {
          setUser(session.user);
          loadMyPostcards(session.user.id);
        } else {
          setUser(null);
        }
        setCheckingAuth(false);
      }
    );

    // Then check for existing session
    checkUser();
    requestLocation();

    return () => subscription.unsubscribe();
  }, []);

  const checkUser = async () => {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session?.user) {
      setCheckingAuth(false);
      toast({
        title: "Autenticación requerida",
        description: "Debes iniciar sesión para usar Postal Mágica.",
        variant: "destructive",
      });
      setTimeout(() => navigate("/auth"), 2000);
      return;
    }
    setUser(session.user);
    loadMyPostcards(session.user.id);
    setCheckingAuth(false);
  };

  const loadMyPostcards = async (userId: string) => {
    const { data, error } = await supabase
      .from("magic_postcards")
      .select("*")
      .eq("user_id", userId)
      .order("created_at", { ascending: false })
      .limit(10);

    if (!error && data) {
      setMyPostcards(data);
    }
  };

  const requestLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          });
        },
        (error) => {
          toast({
            title: "Ubicación requerida",
            description: "Necesitamos tu ubicación para verificar que estás en la Comarca Andina.",
            variant: "destructive",
          });
        }
      );
    }
  };

  // Utilidad: comprime/redimensiona imagen en el cliente para acelerar subida
  const compressImageToDataUrl = (file: File, maxDim = 1280, quality = 0.8): Promise<string> => {
    return new Promise((resolve, reject) => {
      const img = new Image();
      const reader = new FileReader();
      reader.onload = () => {
        img.onload = () => {
          const canvas = document.createElement('canvas');
          let { width, height } = img as HTMLImageElement & { width: number; height: number };
          const scale = Math.min(1, maxDim / Math.max(width, height));
          width = Math.round(width * scale);
          height = Math.round(height * scale);
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          if (!ctx) return reject(new Error('Canvas no soportado'));
          ctx.drawImage(img, 0, 0, width, height);
          const mime = file.type.includes('png') ? 'image/png' : 'image/jpeg';
          const dataUrl = canvas.toDataURL(mime, quality);
          resolve(dataUrl);
        };
        img.onerror = () => reject(new Error('No se pudo cargar la imagen'));
        img.src = reader.result as string;
      };
      reader.onerror = () => reject(new Error('No se pudo leer el archivo'));
      reader.readAsDataURL(file);
    });
  };

  // Utilidad: timeout para promesas (no cancela la red, pero deja de esperar)
  const withTimeout = <T,>(p: Promise<T>, ms: number): Promise<T> => {
    return new Promise((resolve, reject) => {
      const id = setTimeout(() => reject(new Error('timeout')), ms);
      p.then((v) => { clearTimeout(id); resolve(v); })
       .catch((e) => { clearTimeout(id); reject(e); });
    });
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        toast({
          title: "Archivo muy grande",
          description: "La imagen debe ser menor a 5MB.",
          variant: "destructive",
        });
        return;
      }

      setImageFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleGenerate = async () => {
    if (!imageFile || !prompt || !location) {
      toast({
        title: "Datos incompletos",
        description: "Necesitas subir una foto, agregar una descripción y permitir ubicación.",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    setGeneratedImage(null);

    try {
      const imageBase64 = await compressImageToDataUrl(imageFile, 800, 0.60);

      const result: any = await supabase.functions.invoke("generate-magic-postcard", {
        body: {
          imageBase64,
          prompt,
          latitude: location.lat,
          longitude: location.lng,
        },
      });

      const { data, error } = result;

      if (error) {
        const status = (error as any)?.status;
        let msg = (error as any)?.message || "Error al generar postal.";
        if (status === 429) msg = "Límite alcanzado. Intenta más tarde.";
        if (status === 402) msg = "Servicio no disponible. Intenta más tarde.";
        toast({ title: "Error", description: msg, variant: "destructive" });
        setLoading(false);
        return;
      }

      if (data?.error) {
        toast({ title: "Error", description: data.error, variant: "destructive" });
        setLoading(false);
        return;
      }

      setGeneratedImage(data.imageUrl);
      setRemaining(data.remaining);
      
      if (data.processing) {
        toast({ 
          title: "¡Postal creada! ✨", 
          description: "Generando magia con IA... Esto puede tardar hasta 60s. Puedes cerrar y volver más tarde." 
        });
        
        // Poll para actualizar cuando esté lista
        const postcardId = data.postcard?.id;
        if (postcardId) {
          const pollInterval = setInterval(async () => {
            const { data: updated } = await supabase
              .from("magic_postcards")
              .select("image_url")
              .eq("id", postcardId)
              .single();
            
            if (updated && updated.image_url !== data.imageUrl) {
              setGeneratedImage(updated.image_url);
              toast({ title: "¡Magia completa!", description: "Tu postal mágica está lista!" });
              clearInterval(pollInterval);
            }
          }, 5000); // Check cada 5s
          
          // Limpiar después de 90s
          setTimeout(() => clearInterval(pollInterval), 90000);
        }
      } else {
        toast({ title: "¡Postal creada! ✨", description: data.message });
      }

      if (user) {
        loadMyPostcards(user.id);
      }
    } catch (e: any) {
      console.error(e);
      toast({
        title: 'Error',
        description: e?.message || 'Error al generar postal.',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    navigate("/");
  };

  const handleDownload = () => {
    if (generatedImage) {
      const link = document.createElement("a");
      link.href = generatedImage;
      link.download = "postal-magica-andes.png";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  // Show loading state while checking auth
  if (checkingAuth) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-primary/5 to-background p-4 sm:p-8 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-8 h-8 animate-spin mx-auto mb-4 text-primary" />
          <p className="text-muted-foreground">Verificando autenticación...</p>
        </div>
      </div>
    );
  }

  // Show auth required if no user
  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-primary/5 to-background p-4 sm:p-8 flex items-center justify-center">
        <Card className="max-w-md">
          <CardHeader>
            <CardTitle>Autenticación requerida</CardTitle>
            <CardDescription>
              Debes iniciar sesión para acceder a Postal Mágica
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button onClick={() => navigate("/auth")} className="w-full">
              Ir a iniciar sesión
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-primary/5 to-background p-4 sm:p-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
          <div>
            <h1 className="text-3xl sm:text-4xl font-bold text-primary flex items-center gap-2">
              <Sparkles className="w-8 h-8" />
              Postal Mágica
            </h1>
            <p className="text-muted-foreground mt-2">
              Transforma tus fotos de la Patagonia en obras mágicas con IA
            </p>
          </div>
          <div className="flex items-center gap-4">
            {user && (
              <>
                <div className="text-sm text-muted-foreground">
                  {user.email}
                </div>
                <Button variant="outline" size="sm" onClick={handleSignOut}>
                  <LogOut className="w-4 h-4 mr-2" />
                  Salir
                </Button>
              </>
            )}
          </div>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Crear Postal */}
          <Card>
            <CardHeader>
              <CardTitle>Crear Postal Mágica</CardTitle>
              <CardDescription>
                Sube una foto y descríbenos qué elementos mágicos quieres agregar
              </CardDescription>
              {remaining !== null && (
                <div className="flex items-center gap-2 text-sm">
                  <Sparkles className="w-4 h-4 text-primary" />
                  <span>Postales restantes hoy: {remaining}</span>
                </div>
              )}
              {location && (
                <div className="flex items-center gap-2 text-sm text-green-600">
                  <MapPin className="w-4 h-4" />
                  <span>Ubicación verificada en Comarca Andina</span>
                </div>
              )}
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Upload de imagen */}
              <div>
                <label className="block text-sm font-medium mb-2">Tu foto</label>
                <div className="border-2 border-dashed rounded-lg p-8 text-center hover:border-primary transition-colors cursor-pointer">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleFileChange}
                    className="hidden"
                    id="file-upload"
                  />
                  <label htmlFor="file-upload" className="cursor-pointer">
                    {imagePreview ? (
                      <img
                        src={imagePreview}
                        alt="Preview"
                        className="max-h-64 mx-auto rounded-lg"
                      />
                    ) : (
                      <div className="flex flex-col items-center gap-2 text-muted-foreground">
                        <Upload className="w-12 h-12" />
                        <p>Haz clic para subir tu foto</p>
                        <p className="text-xs">PNG, JPG hasta 5MB</p>
                      </div>
                    )}
                  </label>
                </div>
              </div>

              {/* Prompt */}
              <div>
                <label className="block text-sm font-medium mb-2">
                  ¿Qué magia quieres agregar?
                </label>
                <div className="relative">
                  <Textarea
                    placeholder="Ej: Agrega auroras boreales mágicas en el cielo... (o usa el micrófono)"
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    rows={4}
                    className="resize-none pr-12"
                  />
                  <div className="absolute right-2 bottom-2">
                    <VoiceInput 
                      onTranscript={(text) => setPrompt(prompt + " " + text)}
                    />
                  </div>
                </div>
              </div>

              <Button
                onClick={handleGenerate}
                disabled={loading || !imageFile || !prompt || !location}
                className="w-full"
                size="lg"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Creando magia...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 mr-2" />
                    Crear Postal Mágica
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          {/* Resultado */}
          <div className="space-y-8">
            {generatedImage && (
              <Card>
                <CardHeader>
                  <CardTitle>¡Tu Postal Mágica!</CardTitle>
                </CardHeader>
                <CardContent>
                  <img
                    src={generatedImage}
                    alt="Postal mágica generada"
                    className="w-full rounded-lg shadow-lg"
                  />
                  <Button onClick={handleDownload} className="w-full mt-4" variant="outline">
                    <ImageIcon className="w-4 h-4 mr-2" />
                    Descargar Postal
                  </Button>
                </CardContent>
              </Card>
            )}

            {/* Mis postales */}
            {myPostcards.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Mis Postales</CardTitle>
                  <CardDescription>Tus últimas creaciones mágicas</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4">
                    {myPostcards.map((postcard) => (
                      <div key={postcard.id} className="relative group">
                        <img
                          src={postcard.image_url}
                          alt="Postal"
                          className="w-full rounded-lg shadow-md hover:shadow-xl transition-shadow"
                        />
                        <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity rounded-lg flex items-center justify-center">
                          <a
                            href={postcard.image_url}
                            download
                            className="text-white text-sm bg-primary px-3 py-1 rounded"
                          >
                            Descargar
                          </a>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
