import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { ShieldCheck, ShieldOff } from "lucide-react";
import { toast } from "sonner";
import { isAdminMode, enableAdminMode, disableAdminMode } from "@/lib/usage-limits";

export const AdminModeToggle = () => {
  const [open, setOpen] = useState(false);
  const [code, setCode] = useState("");
  const [adminActive, setAdminActive] = useState(isAdminMode());

  const handleActivate = () => {
    if (enableAdminMode(code)) {
      setAdminActive(true);
      toast.success("Modo desarrollador activado - Sin límites de uso");
      setOpen(false);
      setCode("");
    } else {
      toast.error("Código incorrecto");
    }
  };

  const handleDeactivate = () => {
    disableAdminMode();
    setAdminActive(false);
    toast.info("Modo desarrollador desactivado");
  };

  return (
    <div className="fixed bottom-4 right-4 z-50">
      {adminActive ? (
        <Button
          variant="outline"
          size="sm"
          onClick={handleDeactivate}
          className="bg-green-500/10 border-green-500 text-green-700 hover:bg-green-500/20"
        >
          <ShieldCheck className="h-4 w-4 mr-2" />
          Modo Dev Activo
        </Button>
      ) : (
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button variant="ghost" size="sm" className="opacity-50 hover:opacity-100">
              <ShieldOff className="h-4 w-4" />
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Modo Desarrollador</DialogTitle>
              <DialogDescription>
                Ingresa el código para activar el modo sin límites de uso
              </DialogDescription>
            </DialogHeader>
            <div className="py-4">
              <Input
                type="password"
                placeholder="Código de acceso"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleActivate()}
              />
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setOpen(false)}>
                Cancelar
              </Button>
              <Button onClick={handleActivate}>Activar</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
};
