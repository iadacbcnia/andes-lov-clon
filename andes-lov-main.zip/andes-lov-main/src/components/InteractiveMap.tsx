import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, MapPin, Camera, Navigation, Eye, Star, Phone, Globe } from "lucide-react";
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

interface InteractiveMapProps {
  onBack: () => void;
  selectedPlaceId?: string;
  selectedPlaceName?: string;
  selectedPlaceDescription?: string;
  selectedPlaceLatitude?: number;
  selectedPlaceLongitude?: number;
}

interface Place {
  id: string;
  name: string;
  type: string;
  location: string;
  coordinates: { lat: number; lng: number };
  description: string;
  imageUrl?: string;
  vrImageUrl?: string;
  rating?: number;
  phone?: string;
  website?: string;
  highlights: string[];
}

export const InteractiveMap = ({ 
  onBack, 
  selectedPlaceId, 
  selectedPlaceName, 
  selectedPlaceDescription,
  selectedPlaceLatitude,
  selectedPlaceLongitude 
}: InteractiveMapProps) => {
  const [selectedPlace, setSelectedPlace] = useState<Place | null>(null);
  const [viewMode, setViewMode] = useState<"map" | "vr">("map");
  const simpleMode = !!selectedPlaceId; // Si viene desde el chat, mostramos solo el mapa
  const mapRef = useRef<L.Map | null>(null);
  const markersRef = useRef<Record<string, L.Marker>>({});
  const mapElRef = useRef<HTMLDivElement | null>(null);

  // Fix for default markers in Leaflet
  useEffect(() => {
    // Fix for Leaflet default markers not showing
    delete (L.Icon.Default.prototype as any)._getIconUrl;
    L.Icon.Default.mergeOptions({
      iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
      iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
      shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
    });
  }, []);

  // Initialize Leaflet map
  useEffect(() => {
    if (viewMode !== 'map') return;
    if (mapRef.current || !mapElRef.current) return;

    // Determine initial center
    const initialLat = selectedPlaceLatitude || -41.96;
    const initialLng = selectedPlaceLongitude || -71.53;
    const initialZoom = selectedPlaceLatitude ? 14 : 12;

    const map = L.map(mapElRef.current, {
      center: [initialLat, initialLng],
      zoom: initialZoom,
    });

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);

    // If we have a selected place from props, add its marker first
    if (selectedPlaceId && selectedPlaceName && selectedPlaceLatitude && selectedPlaceLongitude) {
      const marker = L.marker([selectedPlaceLatitude, selectedPlaceLongitude], {
        icon: createCustomIcon('#10B981'),
        title: selectedPlaceName,
      }).addTo(map);

      const popupHtml = `
        <div style="min-width:250px;padding:8px;">
          <div style="font-weight:600;font-size:1.1rem;margin-bottom:8px;">${selectedPlaceName}</div>
          ${selectedPlaceDescription ? `<div style="font-size:0.9rem;color:#444;margin-bottom:12px;">${selectedPlaceDescription}</div>` : ''}
          <a 
            href="https://www.google.com/maps/dir/?api=1&destination=${selectedPlaceLatitude},${selectedPlaceLongitude}&travelmode=driving" 
            target="_blank" rel="noopener noreferrer"
            style="display:inline-block;width:100%;padding:8px 16px;background:#10B981;color:white;text-align:center;text-decoration:none;border-radius:6px;cursor:pointer;font-weight:500;font-size:0.9rem;"
          >
            🧭 Cómo Llegar
          </a>
        </div>`;
      marker.bindPopup(popupHtml).openPopup();

      markersRef.current[selectedPlaceId] = marker;
    }

    // Add other place markers solo si no estamos en simpleMode
    if (!simpleMode) {
      places.forEach((place) => {
        // Skip if this is the same as selected place
        if (selectedPlaceId && place.id === selectedPlaceId) return;

        const marker = L.marker([place.coordinates.lat, place.coordinates.lng], {
          icon: createCustomIcon(),
          title: place.name,
        })
          .addTo(map)
          .on('click', () => setSelectedPlace(place));

        const popupHtml = `
          <div style="min-width:200px;padding:4px 0;">
            <div style="display:flex;gap:8px;align-items:flex-start;">
              ${place.imageUrl ? `<img src="${place.imageUrl}" alt="${place.name}" style="width:64px;height:64px;border-radius:8px;object-fit:cover;" />` : ''}
              <div style="flex:1;">
                <div style="font-weight:600;font-size:0.95rem;margin-bottom:2px;">${place.name}</div>
                <div style="font-size:0.8rem;color:#555;margin-bottom:4px;">📍 ${place.location}</div>
                <div style="font-size:0.8rem;color:#444;">${place.description}</div>
              </div>
            </div>
          </div>`;
        marker.bindPopup(popupHtml);

        markersRef.current[place.id] = marker;
      });
    }

    mapRef.current = map;
  }, [viewMode, selectedPlaceId, selectedPlaceName, selectedPlaceDescription, selectedPlaceLatitude, selectedPlaceLongitude]);

  // Center map when selecting a place or switching back to map view
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    if (selectedPlace && viewMode === 'map') {
      map.flyTo([selectedPlace.coordinates.lat, selectedPlace.coordinates.lng], 13, { duration: 1 });
      const marker = markersRef.current[selectedPlace.id];
      if (marker) marker.openPopup();
    }
  }, [selectedPlace, viewMode]);

  // Custom marker icon
  const createCustomIcon = (color: string = '#3B82F6') => {
    return L.divIcon({
      html: `<div style="background-color: ${color}; width: 24px; height: 24px; border-radius: 50%; border: 3px solid white; box-shadow: 0 2px 6px rgba(0,0,0,0.3); display: flex; align-items: center; justify-content: center;"><div style="color: white; font-size: 12px;">📍</div></div>`,
      className: 'custom-marker',
      iconSize: [24, 24],
      iconAnchor: [12, 12],
    });
  };

  const places: Place[] = [
    {
      id: "1",
      name: "Cerro Piltriquitrón",
      type: "Mirador",
      location: "El Bolsón",
      coordinates: { lat: -41.96, lng: -71.53 },
      description: "El mirador más famoso de El Bolsón con vistas panorámicas de 360° de la Comarca Andina",
      imageUrl: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=600&h=400&fit=crop",
      vrImageUrl: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=1200&h=600&fit=crop",
      rating: 4.8,
      highlights: ["Vista 360°", "Trekking", "Fotografía", "Atardecer"]
    },
    {
      id: "2",
      name: "Lago Puelo",
      type: "Lugar para Visitar",
      location: "Lago Puelo",
      coordinates: { lat: -42.05, lng: -71.62 },
      description: "Lago de aguas cristalinas rodeado de bosques andino-patagónicos",
      imageUrl: "https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=600&h=400&fit=crop",
      vrImageUrl: "https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=1200&h=600&fit=crop",
      rating: 4.9,
      highlights: ["Navegación", "Pesca", "Camping", "Naturaleza"]
    },
    {
      id: "3",
      name: "Feria Artesanal",
      type: "Lugar para Visitar",
      location: "El Bolsón",
      coordinates: { lat: -41.965, lng: -71.535 },
      description: "Feria de productos regionales y artesanías locales",
      imageUrl: "https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=600&h=400&fit=crop",
      rating: 4.5,
      highlights: ["Artesanías", "Productos locales", "Gastronomía", "Cultura"]
    }
  ];

  const PlaceCard = ({ place }: { place: Place }) => (
    <Card 
      className="cursor-pointer hover:shadow-lg transition-all border-0 shadow-md"
      onClick={() => setSelectedPlace(place)}
    >
      <div className="relative h-48 overflow-hidden rounded-t-lg">
        <img 
          src={place.imageUrl} 
          alt={place.name}
          className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
        />
        <div className="absolute top-4 right-4">
          <Badge variant="secondary" className="bg-white/90 text-foreground">
            {place.type}
          </Badge>
        </div>
        {place.rating && (
          <div className="absolute bottom-4 left-4">
            <Badge variant="secondary" className="bg-black/50 text-white">
              <Star className="w-3 h-3 mr-1 fill-current" />
              {place.rating}
            </Badge>
          </div>
        )}
      </div>
      <CardContent className="p-4">
        <h3 className="font-semibold text-lg mb-1">{place.name}</h3>
        <p className="text-sm text-muted-foreground mb-3">📍 {place.location}</p>
        <p className="text-sm mb-3 line-clamp-2">{place.description}</p>
        <div className="flex flex-wrap gap-1">
          {place.highlights.slice(0, 3).map((highlight, index) => (
            <Badge key={index} variant="outline" className="text-xs">
              {highlight}
            </Badge>
          ))}
        </div>
      </CardContent>
    </Card>
  );

  // Add global function for Google Maps
  useEffect(() => {
    (window as any).openGoogleMaps = (lat: number, lng: number) => {
      // URL que abre Google Maps con direcciones desde la ubicación actual del usuario
      const url = `https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}&travelmode=driving`;
      window.open(url, '_blank', 'noopener,noreferrer');
    };

    return () => {
      delete (window as any).openGoogleMaps;
    };
  }, []);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-gradient-hero text-white p-4 shadow-lg">
        <div className="container mx-auto flex items-center gap-4">
          <Button 
            variant="ghost" 
            size="icon"
            onClick={onBack}
            className="text-white hover:bg-white/10"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div className="flex-1">
            <h1 className="text-xl font-semibold">Mapa Interactivo de la Comarca</h1>
            <p className="text-sm text-white/80">Explora lugares en el mapa</p>
          </div>
          {!simpleMode && (
            <div className="flex gap-2">
              <Button
                variant={viewMode === "map" ? "secondary" : "ghost"}
                size="sm"
                onClick={() => setViewMode("map")}
                className="text-white hover:bg-white/10"
              >
                <MapPin className="w-4 h-4 mr-1" />
                Mapa
              </Button>
              <Button
                variant={viewMode === "vr" ? "secondary" : "ghost"}
                size="sm"
                onClick={() => setViewMode("vr")}
                className="text-white hover:bg-white/10"
                disabled={!selectedPlace?.vrImageUrl}
              >
                <Eye className="w-4 h-4 mr-1" />
                VR
              </Button>
            </div>
          )}
        </div>
      </header>

      {simpleMode ? (
        <div className="h-[calc(100vh-80px)]">
          <div className="w-full h-full relative">
            <div ref={mapElRef} className="absolute inset-0" />
          </div>
        </div>
      ) : (
        <div className="flex flex-col lg:flex-row h-[calc(100vh-80px)]">
          {/* Map/VR View */}
          <div className="flex-1 relative">
            {viewMode === "map" ? (
              <div className="w-full h-full relative">
                <div ref={mapElRef} className="absolute inset-0" />
              </div>
            ) : (
              <div className="w-full h-full bg-black flex items-center justify-center">
                {selectedPlace?.vrImageUrl ? (
                  <div className="relative w-full h-full">
                    <img 
                      src={selectedPlace.vrImageUrl} 
                      alt={`Vista 360° de ${selectedPlace.name}`}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-black/20 flex items-center justify-center">
                      <div className="text-white text-center">
                        <Camera className="w-16 h-16 mx-auto mb-4" />
                        <h3 className="text-2xl font-bold mb-2">Vista 360° VR</h3>
                        <p className="text-lg">{selectedPlace.name}</p>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="text-white text-center">
                    <Eye className="w-16 h-16 mx-auto mb-4 opacity-50" />
                    <h3 className="text-xl font-semibold mb-2">Vista VR no disponible</h3>
                    <p className="text-white/70">Selecciona un lugar con vista 360° para ver en VR</p>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div className="w-full lg:w-96 border-l bg-background">
            {selectedPlace ? (
              <div className="p-6 h-full overflow-y-auto custom-scrollbar">
                <div className="space-y-6">
                  {/* Place Header */}
                  <div>
                    <div className="flex items-start justify-between mb-2">
                      <h2 className="text-2xl font-bold">{selectedPlace.name}</h2>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setSelectedPlace(null)}
                      >
                        ✕
                      </Button>
                    </div>
                    <div className="flex items-center gap-2 mb-4">
                      <Badge variant="secondary">{selectedPlace.type}</Badge>
                      <span className="text-muted-foreground">📍 {selectedPlace.location}</span>
                    </div>
                    {selectedPlace.rating && (
                      <div className="flex items-center gap-1 mb-4">
                        <Star className="w-4 h-4 fill-current text-yellow-400" />
                        <span className="font-medium">{selectedPlace.rating}</span>
                        <span className="text-sm text-muted-foreground">/5</span>
                      </div>
                    )}
                  </div>

                  {/* Place Image */}
                  <div className="relative rounded-lg overflow-hidden">
                    <img 
                      src={selectedPlace.imageUrl} 
                      alt={selectedPlace.name}
                      className="w-full h-48 object-cover"
                    />
                    {selectedPlace.vrImageUrl && (
                      <Button
                        size="sm"
                        className="absolute bottom-4 right-4 bg-black/50 hover:bg-black/70"
                        onClick={() => setViewMode("vr")}
                      >
                        <Eye className="w-4 h-4 mr-1" />
                        Ver en VR
                      </Button>
                    )}
                  </div>

                  {/* Description */}
                  <div>
                    <h3 className="font-semibold mb-2">Descripción</h3>
                    <p className="text-muted-foreground">{selectedPlace.description}</p>
                  </div>

                  {/* Highlights */}
                  <div>
                    <h3 className="font-semibold mb-2">Destacados</h3>
                    <div className="flex flex-wrap gap-2">
                      {selectedPlace.highlights.map((highlight, index) => (
                        <Badge key={index} variant="outline">
                          {highlight}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="space-y-3">
                    <Button className="w-full bg-primary hover:bg-primary/90" 
                      onClick={() => (window as any).openGoogleMaps(selectedPlace.coordinates.lat, selectedPlace.coordinates.lng)}
                    >
                      <Navigation className="w-4 h-4 mr-2" />
                      Obtener Direcciones
                    </Button>
                    <div className="grid grid-cols-2 gap-2">
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => alert(`Opiniones de ${selectedPlace.name}:\n\n⭐⭐⭐⭐⭐ "Lugar increíble con vistas espectaculares"\n⭐⭐⭐⭐ "Muy recomendable para familias"\n⭐⭐⭐⭐⭐ "La vista desde aquí es impresionante"`)}
                      >
                        💬 Opiniones
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => {
                          setViewMode("map");
                          // Center handled by effect
                        }}
                      >
                        🗺️ Ver en Mapa
                      </Button>
                    </div>
                    {selectedPlace.phone && (
                      <Button variant="outline" className="w-full" size="sm">
                        <Phone className="w-4 h-4 mr-2" />
                        {selectedPlace.phone}
                      </Button>
                    )}
                    {selectedPlace.website && (
                      <Button variant="outline" className="w-full" size="sm">
                        <Globe className="w-4 h-4 mr-2" />
                        Sitio Web
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            ) : (
              <div className="p-6 h-full overflow-y-auto custom-scrollbar">
                <div className="mb-6">
                  <h2 className="text-xl font-bold mb-2">Lugares Destacados</h2>
                  <p className="text-muted-foreground">Selecciona un lugar para ver más detalles</p>
                </div>
                
                <div className="space-y-4">
                  {places.map((place) => (
                    <PlaceCard key={place.id} place={place} />
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

    </div>
  );
};