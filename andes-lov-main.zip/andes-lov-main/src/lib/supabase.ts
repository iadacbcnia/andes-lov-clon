import { createClient } from '@supabase/supabase-js';

// Configuración temporal - esto se configurará automáticamente cuando Supabase esté completamente integrado
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://temp.supabase.co';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'temp-key';

export const supabase = supabaseUrl && supabaseAnonKey && supabaseUrl !== 'https://temp.supabase.co' 
  ? createClient(supabaseUrl, supabaseAnonKey)
  : null;

export interface Place {
  id: string;
  nombre: string;
  tipo: string;
  subtipo?: string;
  localidad: string;
  descripcion?: string;
  direccion?: string;
  telefono?: string;
  email?: string;
  web?: string;
  instagram?: string;
  facebook?: string;
  horarios?: string;
  precios?: string;
  servicios?: string;
  datos_clave?: string;
  imagen_url?: string;
  imagen_360_url?: string;
  latitud?: number;
  longitud?: number;
  es_auspiciante?: boolean;
  created_at?: string;
}

export const searchPlaces = async (query: string): Promise<Place[]> => {
  if (!supabase) {
    console.log('Supabase not configured, returning mock data');
    return mockPlaces.filter(place => 
      place.nombre.toLowerCase().includes(query.toLowerCase()) ||
      place.descripcion.toLowerCase().includes(query.toLowerCase()) ||
      place.localidad.toLowerCase().includes(query.toLowerCase()) ||
      place.tipo.toLowerCase().includes(query.toLowerCase())
    ).slice(0, 5);
  }

  try {
    const { data, error } = await supabase
      .from('places')
      .select('*')
      .or(`nombre.ilike.%${query}%, descripcion.ilike.%${query}%, localidad.ilike.%${query}%, tipo.ilike.%${query}%`)
      .limit(5);

    if (error) {
      console.error('Error searching places:', error);
      return [];
    }

    return data || [];
  } catch (error) {
    console.error('Error in searchPlaces:', error);
    return [];
  }
};

export const getPlacesByType = async (tipo: string): Promise<Place[]> => {
  if (!supabase) {
    console.log('Supabase not configured, returning mock data');
    return mockPlaces.filter(place => 
      place.tipo.toLowerCase().includes(tipo.toLowerCase())
    ).slice(0, 5);
  }

  try {
    const { data, error } = await supabase
      .from('places')
      .select('*')
      .ilike('tipo', `%${tipo}%`)
      .limit(5);

    if (error) {
      console.error('Error getting places by type:', error);
      return [];
    }

    return data || [];
  } catch (error) {
    console.error('Error in getPlacesByType:', error);
    return [];
  }
};

export const getPlacesByLocation = async (localidad: string): Promise<Place[]> => {
  if (!supabase) {
    console.log('Supabase not configured, returning mock data');
    return mockPlaces.filter(place => 
      place.localidad.toLowerCase().includes(localidad.toLowerCase())
    ).slice(0, 5);
  }

  try {
    const { data, error } = await supabase
      .from('places')
      .select('*')
      .ilike('localidad', `%${localidad}%`)
      .limit(5);

    if (error) {
      console.error('Error getting places by location:', error);
      return [];
    }

    return data || [];
  } catch (error) {
    console.error('Error in getPlacesByLocation:', error);
    return [];
  }
};

// Datos de ejemplo mientras se configura Supabase
const mockPlaces: Place[] = [
  {
    id: '1',
    nombre: 'Cabañas del Bosque',
    tipo: 'Cabaña',
    localidad: 'El Hoyo',
    descripcion: 'Hermosas cabañas en medio del bosque con vista panorámica'
  },
  {
    id: '2',
    nombre: 'Refugio Andino',
    tipo: 'Cabaña',
    localidad: 'El Bolsón',
    descripcion: 'Cabañas de montaña con todas las comodidades'
  },
  {
    id: '3',
    nombre: 'Casa del Lago',
    tipo: 'Cabaña',
    localidad: 'Lago Puelo',
    descripcion: 'Cabaña frente al lago con deck privado'
  }
];