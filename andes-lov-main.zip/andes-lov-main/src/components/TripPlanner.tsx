import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";
import { ArrowLeft, Mountain, Heart, Users, Zap, Calendar, MapPin, Star, MessageCircle } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { canUseFeature, incrementUsage, getRemainingUses } from "@/lib/usage-limits";

interface TripPlannerProps {
  onBack: () => void;
}

type TravelStyle = "adventure" | "relax" | "family" | null;
type EnergyLevel = "low" | "medium" | "high";

interface PlanDay {
  day: number;
  title: string;
  activities: Array<{
    name: string;
    type: string;
    location: string;
    description: string;
    duration: string;
  }>;
}

export const TripPlanner = ({ onBack }: TripPlannerProps) => {
  const [step, setStep] = useState(1);
  const [travelStyle, setTravelStyle] = useState<TravelStyle>(null);
  const [days, setDays] = useState([3]);
  const [selectedLocations, setSelectedLocations] = useState<string[]>([]);
  const [energyLevel, setEnergyLevel] = useState<EnergyLevel>("medium");
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedPlan, setGeneratedPlan] = useState<PlanDay[] | null>(null);

  const travelStyles = [
    {
      id: "adventure" as const,
      name: "Aventura",
      icon: Mountain,
      description: "Trekking, deportes extremos y exploración",
      color: "text-orange-500"
    },
    {
      id: "relax" as const,
      name: "Relax",
      icon: Heart,
      description: "Descanso, termas y contemplación",
      color: "text-blue-500"
    },
    {
      id: "family" as const,
      name: "Familiar",
      icon: Users,
      description: "Actividades para toda la familia",
      color: "text-green-500"
    }
  ];

  const energyLevels = {
    low: { label: "Bajo", description: "Ritmo tranquilo y relajado", color: "bg-blue-500" },
    medium: { label: "Medio", description: "Equilibrio entre actividad y descanso", color: "bg-yellow-500" },
    high: { label: "Alto", description: "Máxima actividad y aventura", color: "bg-red-500" }
  };

  const availableLocations = [
    { id: "el-bolson", name: "El Bolsón", description: "Centro urbano con feria artesanal y cervecerías" },
    { id: "lago-puelo", name: "Lago Puelo", description: "Parque Nacional con actividades acuáticas" },
    { id: "el-hoyo", name: "El Hoyo", description: "Naturaleza y cabañas en el bosque" },
    { id: "epuyen", name: "Epuyén", description: "Pueblo tranquilo ideal para descanso" },
    { id: "cholila", name: "Cholila", description: "Historia gaucha y paisajes únicos" },
    { id: "el-maiten", name: "El Maitén", description: "Pueblo ferroviario con historia y tradición" }
  ];

  const generatePlan = async () => {
    // Verificar límite de uso
    if (!canUseFeature('tripPlanner')) {
      toast.error(`Has usado tus ${getRemainingUses('tripPlanner')} planes diarios. Vuelve mañana.`);
      return;
    }
    
    setIsGenerating(true);
    
    try {
      // Buscar lugares reales en las localidades seleccionadas
      const locationsToSearch = selectedLocations.length > 0 
        ? selectedLocations 
        : availableLocations.map(loc => loc.id);

      // Obtener lugares de la base de datos
      const { data: places, error } = await supabase
        .from('places')
        .select('*')
        .in('localidad', locationsToSearch.map(loc => {
          const location = availableLocations.find(l => l.id === loc);
          return location ? location.name : loc;
        }))
        .order('categoria_auspiciante', { ascending: false })
        .limit(30);

      if (error) {
        console.error('Error fetching places:', error);
        toast.error('Error al obtener lugares de la base de datos');
        setIsGenerating(false);
        return;
      }

      // Preparar el contexto para la IA
      const placesContext = places?.map(p => 
        `${p.nombre} (${p.tipo}) en ${p.localidad}${p.descripcion ? ': ' + p.descripcion : ''}${p.categoria_auspiciante > 0 ? ' [RECOMENDADO ⭐'.repeat(p.categoria_auspiciante) + ']' : ''}`
      ).join('\n') || '';

      const locationNames = selectedLocations.map(id => 
        availableLocations.find(l => l.id === id)?.name
      ).filter(Boolean).join(', ') || 'toda la Comarca Andina';

      // Llamar a la función edge para generar el plan con IA
      const { data: aiResponse, error: aiError } = await supabase.functions.invoke('generate-trip-plan', {
        body: {
          travelStyle,
          days: days[0],
          locations: locationNames,
          energyLevel,
          availablePlaces: placesContext
        }
      });

      if (aiError) {
        console.error('Error generating plan:', aiError);
        toast.error('Error al generar el plan. Intenta nuevamente.');
        setIsGenerating(false);
        return;
      }

      setGeneratedPlan(aiResponse.plan);
      setIsGenerating(false);
      setStep(4);
      
      // Incrementar contador solo si fue exitoso
      incrementUsage('tripPlanner');
      toast.success('¡Plan generado exitosamente!');

    } catch (error) {
      console.error('Error:', error);
      toast.error('Error al generar el plan');
      setIsGenerating(false);
    }
  };

  const sendToWhatsApp = () => {
    if (!generatedPlan) return;

    let message = `🏔️ Mi Plan de Viaje por la Comarca Andina 🏔️\n\n`;
    message += `📅 ${days[0]} días | 🎯 Estilo: ${travelStyle} | ⚡ Energía: ${energyLevels[energyLevel].label}\n`;
    message += `📍 Localidades: ${selectedLocations.length > 0 ? selectedLocations.join(', ') : 'Todas'}\n`;
    message += `🤖 Generado por Andes IA\n\n`;

    generatedPlan.forEach((planDay) => {
      message += `DÍA ${planDay.day}: ${planDay.title}\n`;
      planDay.activities.forEach((activity) => {
        message += `📍 ${activity.name} (${activity.duration})\n`;
        message += `   📋 ${activity.description}\n`;
        message += `   🏷️ ${activity.type} | 📌 ${activity.location}\n\n`;
      });
      message += `\n`;
    });

    message += `🌟 ¡Que disfrutes tu aventura en la Patagonia!\n`;
    message += `📱 Creado con Andes - Tu asistente turístico IA`;

    // Try to use WhatsApp directly
    const encodedMessage = encodeURIComponent(message);
    
    // Use the web.whatsapp.com URL instead of wa.me to avoid blocks
    const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
    
    if (isMobile) {
      // On mobile, try the whatsapp:// protocol first
      const whatsappUrl = `whatsapp://send?text=${encodedMessage}`;
      window.location.href = whatsappUrl;
    } else {
      // On desktop, copy to clipboard as fallback
      navigator.clipboard.writeText(message).then(() => {
        alert('¡Plan copiado al portapapeles! Pégalo en WhatsApp Web o cualquier chat.');
      }).catch(() => {
        // If clipboard doesn't work, show the text in a new window
        const newWindow = window.open('', '_blank');
        if (newWindow) {
          newWindow.document.write(`
            <html>
              <head><title>Tu Plan de Viaje</title></head>
              <body style="font-family: Arial, sans-serif; padding: 20px; white-space: pre-wrap;">
                <h2>Copia este texto y pégalo en WhatsApp:</h2>
                <div style="background: #f5f5f5; padding: 15px; border-radius: 5px; margin: 10px 0;">
                  ${message.replace(/\n/g, '<br>')}
                </div>
                <button onclick="navigator.clipboard.writeText('${message.replace(/'/g, "\\'")}'); alert('¡Copiado!')">Copiar Texto</button>
              </body>
            </html>
          `);
        }
      });
    }
  };

  if (generatedPlan) {
    return (
      <div className="min-h-screen bg-background">
        {/* Header */}
        <header className="bg-gradient-hero text-white p-4 shadow-lg">
          <div className="container mx-auto flex items-center gap-4">
            <Button 
              variant="ghost" 
              size="icon"
              onClick={onBack}
              className="text-white hover:bg-white/10"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-xl font-semibold">Tu Plan Personalizado</h1>
              <p className="text-sm text-white/80">{days[0]} días en la Comarca Andina</p>
            </div>
          </div>
        </header>

        {/* Generated Plan */}
        <div className="container mx-auto px-4 py-8 max-w-4xl">
          <div className="mb-8 text-center">
            <div className="inline-flex items-center gap-2 bg-primary/10 px-4 py-2 rounded-full mb-4">
              <Star className="w-4 h-4 text-primary" />
              <span className="text-sm font-medium text-primary">Plan Generado por Andes</span>
            </div>
            <h2 className="text-2xl font-bold mb-2">¡Tu aventura está lista!</h2>
            <p className="text-muted-foreground">
              Plan {travelStyle} de {days[0]} días con nivel de energía {energyLevels[energyLevel].label.toLowerCase()}
              {selectedLocations.length > 0 && (
                <span className="block text-sm mt-1">
                  Localidades: {selectedLocations.join(', ')}
                </span>
              )}
            </p>
          </div>

          <div className="space-y-8">
            {generatedPlan.map((planDay) => (
              <Card key={planDay.day} className="border-0 shadow-lg">
                <CardHeader className="bg-gradient-hero text-white">
                  <CardTitle className="flex items-center gap-3">
                    <Badge variant="secondary" className="bg-white/20 text-white">
                      Día {planDay.day}
                    </Badge>
                    {planDay.title}
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="space-y-4">
                    {planDay.activities.map((activity, index) => (
                      <div key={index} className="flex gap-4 p-4 bg-muted/30 rounded-lg">
                        <div className="flex-shrink-0">
                          <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
                            <MapPin className="w-5 h-5 text-primary" />
                          </div>
                        </div>
                        <div className="flex-1">
                          <div className="flex items-start justify-between mb-2">
                            <h4 className="font-semibold">{activity.name}</h4>
                            <Badge variant="outline" className="text-xs">
                              {activity.duration}
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground mb-2">
                            {activity.description}
                          </p>
                          <div className="flex gap-2">
                            <Badge variant="secondary" className="text-xs">
                              {activity.type}
                            </Badge>
                            <Badge variant="outline" className="text-xs">
                              📍 {activity.location}
                            </Badge>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="mt-8 flex gap-4 justify-center">
            <Button 
              variant="outline"
              onClick={() => {
                setGeneratedPlan(null);
                setStep(1);
                setTravelStyle(null);
                setSelectedLocations([]);
              }}
            >
              Crear Nuevo Plan
            </Button>
            <Button 
              className="bg-green-600 hover:bg-green-700 text-white"
              onClick={sendToWhatsApp}
            >
              <MessageCircle className="w-4 h-4 mr-2" />
              Enviar por WhatsApp
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-gradient-hero text-white p-4 shadow-lg">
        <div className="container mx-auto flex items-center gap-4">
          <Button 
            variant="ghost" 
            size="icon"
            onClick={onBack}
            className="text-white hover:bg-white/10"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-xl font-semibold">Planificador de Viaje Inteligente</h1>
            <p className="text-sm text-white/80">Andes creará un plan a tu medida con solo 4 preguntas</p>
          </div>
        </div>
      </header>

      {/* Progress */}
      <div className="bg-white border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between max-w-lg mx-auto">
            {[1, 2, 3, 4].map((stepNumber) => (
              <div key={stepNumber} className="flex items-center">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium
                  ${step >= stepNumber ? 'bg-primary text-white' : 'bg-muted text-muted-foreground'}`}>
                  {stepNumber}
                </div>
                {stepNumber < 4 && (
                  <div className={`w-12 h-1 mx-2 ${step > stepNumber ? 'bg-primary' : 'bg-muted'}`} />
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8 max-w-2xl">
        {step === 1 && (
          <div className="space-y-8 animate-fade-in">
            <div className="text-center">
              <h2 className="text-2xl font-bold mb-4">1. Elige tu estilo de viaje</h2>
              <p className="text-muted-foreground">¿Qué tipo de experiencia buscas en la Comarca Andina?</p>
            </div>
            
            <div className="grid gap-4">
              {travelStyles.map((style) => (
                <Card 
                  key={style.id}
                  className={`cursor-pointer transition-all hover:shadow-lg ${
                    travelStyle === style.id ? 'ring-2 ring-primary shadow-lg' : ''
                  }`}
                  onClick={() => setTravelStyle(style.id)}
                >
                  <CardContent className="p-6">
                    <div className="flex items-center gap-4">
                      <div className={`w-12 h-12 rounded-full bg-gray-100 flex items-center justify-center ${style.color}`}>
                        <style.icon className="w-6 h-6" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-semibold text-lg">{style.name}</h3>
                        <p className="text-muted-foreground">{style.description}</p>
                      </div>
                      {travelStyle === style.id && (
                        <div className="w-6 h-6 bg-primary rounded-full flex items-center justify-center">
                          <div className="w-2 h-2 bg-white rounded-full" />
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <Button 
              className="w-full" 
              size="lg"
              disabled={!travelStyle}
              onClick={() => setStep(2)}
            >
              Continuar
            </Button>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-8 animate-fade-in">
            <div className="text-center">
              <h2 className="text-2xl font-bold mb-4">2. ¿Cuántos días te quedas?</h2>
              <p className="text-muted-foreground">Selecciona la duración de tu viaje</p>
            </div>
            
            <Card className="p-8">
              <div className="space-y-6">
                <div className="text-center">
                  <span className="text-4xl font-bold text-primary">{days[0]}</span>
                  <span className="text-2xl text-muted-foreground ml-2">
                    {days[0] === 1 ? 'día' : 'días'}
                  </span>
                </div>
                
                <Slider
                  value={days}
                  onValueChange={setDays}
                  max={14}
                  min={1}
                  step={1}
                  className="w-full"
                />
                
                <div className="flex justify-between text-sm text-muted-foreground">
                  <span>1 día</span>
                  <span>14 días</span>
                </div>
              </div>
            </Card>

            <div className="flex gap-4">
              <Button variant="outline" onClick={() => setStep(1)} className="flex-1">
                Atrás
              </Button>
              <Button onClick={() => setStep(3)} className="flex-1">
                Continuar
              </Button>
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="space-y-8 animate-fade-in">
            <div className="text-center">
              <h2 className="text-2xl font-bold mb-4">3. ¿Qué localidades te interesan?</h2>
              <p className="text-muted-foreground">
                {days[0] > 3 ? 'Puedes seleccionar las localidades que más te interesen para un plan más personalizado' : 'Selecciona las localidades que quieres visitar'}
              </p>
            </div>
            
            <div className="grid gap-4">
              {availableLocations.map((location) => {
                const isSelected = selectedLocations.includes(location.name);
                return (
                  <Card 
                    key={location.id}
                    className={`cursor-pointer transition-all hover:shadow-lg ${
                      isSelected ? 'ring-2 ring-primary shadow-lg' : ''
                    }`}
                    onClick={() => {
                      if (isSelected) {
                        setSelectedLocations(prev => prev.filter(loc => loc !== location.name));
                      } else {
                        setSelectedLocations(prev => [...prev, location.name]);
                      }
                    }}
                  >
                    <CardContent className="p-6">
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
                          <MapPin className="w-6 h-6 text-primary" />
                        </div>
                        <div className="flex-1">
                          <h3 className="font-semibold text-lg">{location.name}</h3>
                          <p className="text-muted-foreground">{location.description}</p>
                        </div>
                        {isSelected && (
                          <div className="w-6 h-6 bg-primary rounded-full flex items-center justify-center">
                            <div className="w-2 h-2 bg-white rounded-full" />
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>

            <div className="bg-muted/30 p-4 rounded-lg">
              <p className="text-sm text-muted-foreground text-center">
                💡 Si no seleccionas ninguna, Andes incluirá todas las localidades en tu plan
              </p>
            </div>

            <div className="flex gap-4">
              <Button variant="outline" onClick={() => setStep(2)} className="flex-1">
                Atrás
              </Button>
              <Button onClick={() => setStep(4)} className="flex-1">
                Continuar
              </Button>
            </div>
          </div>
        )}

        {step === 4 && (
          <div className="space-y-8 animate-fade-in">
            <div className="text-center">
              <h2 className="text-2xl font-bold mb-4">4. ¿Cuál es tu nivel de energía?</h2>
              <p className="text-muted-foreground">Esto nos ayuda a ajustar la intensidad de las actividades</p>
            </div>
            
            <div className="grid gap-4">
              {(Object.entries(energyLevels) as [EnergyLevel, any][]).map(([level, config]) => (
                <Card 
                  key={level}
                  className={`cursor-pointer transition-all hover:shadow-lg ${
                    energyLevel === level ? 'ring-2 ring-primary shadow-lg' : ''
                  }`}
                  onClick={() => setEnergyLevel(level)}
                >
                  <CardContent className="p-6">
                    <div className="flex items-center gap-4">
                      <div className={`w-4 h-8 rounded-full ${config.color}`} />
                      <div className="flex-1">
                        <h3 className="font-semibold text-lg">{config.label}</h3>
                        <p className="text-muted-foreground">{config.description}</p>
                      </div>
                      {energyLevel === level && (
                        <div className="w-6 h-6 bg-primary rounded-full flex items-center justify-center">
                          <div className="w-2 h-2 bg-white rounded-full" />
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <div className="flex gap-4">
              <Button variant="outline" onClick={() => setStep(3)} className="flex-1">
                Atrás
              </Button>
              <Button 
                onClick={generatePlan}
                disabled={isGenerating}
                className="flex-1 bg-primary hover:bg-primary/90"
              >
                {isGenerating ? (
                  <>
                    <Zap className="w-4 h-4 mr-2 animate-spin" />
                    Generando Plan...
                  </>
                ) : (
                  <>
                    <Zap className="w-4 h-4 mr-2" />
                    Generar mi Plan Inteligente
                  </>
                )}
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};