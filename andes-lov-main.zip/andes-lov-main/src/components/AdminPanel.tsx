import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { ArrowLeft, Plus, Upload, Download, Trash2, Edit, Settings, Database, ChevronRight, ChevronDown, Shield } from "lucide-react";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { useToast } from "@/hooks/use-toast";

interface AdminPanelProps {
  onBack: () => void;
}

interface Place {
  id: string;
  nombre: string;
  tipo: string;
  subtipo?: string;
  localidad: string;
  direccion?: string;
  telefono?: string;
  latitud?: number;
  longitud?: number;
  imagenes: string[];
  imagen360URL?: string;
  descripcion?: string;
  datosClave?: string;
  categoriaAuspiciante: number;
}

export const AdminPanel = ({ onBack }: AdminPanelProps) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [isCheckingAuth, setIsCheckingAuth] = useState(true);
  const [activeTab, setActiveTab] = useState("add-single");
  const [places, setPlaces] = useState<Place[]>([]);
  const [editingPlace, setEditingPlace] = useState<Place | null>(null);
  const [bulkText, setBulkText] = useState("");
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<string | null>(null);
  const [deleteType, setDeleteType] = useState<'place' | 'group' | 'subgroup'>('place');
  const [deleteInfo, setDeleteInfo] = useState<{localidad?: string, tipo?: string}>({});
  const [openGroups, setOpenGroups] = useState<Record<string, boolean>>({});
  const [openSubgroups, setOpenSubgroups] = useState<Record<string, boolean>>({});
  const { toast } = useToast();

  // Form state for adding/editing places
  const [formData, setFormData] = useState({
    tipo: "",
    subtipo: "",
    localidad: "",
    nombre: "",
    direccion: "",
    telefono: "",
    latitud: "",
    longitud: "",
    imagenes: ["", "", "", "", ""],
    imagen360URL: "",
    descripcion: "",
    datosClave: "",
    categoriaAuspiciante: 0
  });

  const tiposLugar = [
    { value: "restaurante", label: "Restaurante" },
    { value: "bar", label: "Bar" },
    { value: "confiteria", label: "Confitería" },
    { value: "casa-te", label: "Casa de Té" },
    { value: "apart-hotel", label: "Apart Hotel" },
    { value: "cabanas", label: "Cabañas" },
    { value: "campings", label: "Campings" },
    { value: "hoteles", label: "Hoteles" },
    { value: "hosterias", label: "Hosterías" },
    { value: "hospedajes", label: "Hospedajes" },
    { value: "hostels", label: "Hostels" },
    { value: "refugios", label: "Refugios" },
    { value: "alquiler-casas", label: "Alquiler de Casas" },
    { value: "alquiler-deptos", label: "Alquiler de Departamentos" },
    { value: "bnb", label: "Bread & Breakfast" },
    { value: "actividades", label: "Actividades" },
    { value: "lugar-visitar", label: "Lugar para Visitar" }
  ];

  const localidades = [
    { value: "El Bolsón", label: "El Bolsón" },
    { value: "Lago Puelo", label: "Lago Puelo" },
    { value: "El Hoyo", label: "El Hoyo" },
    { value: "Epuyén", label: "Epuyén" },
    { value: "El Maitén", label: "El Maitén" },
    { value: "Cholila", label: "Cholila" }
  ];

  // Verificar sesión real del backend y rol de admin
  useEffect(() => {
    const init = async () => {
      setIsCheckingAuth(true);
      const { data: { session } } = await supabase.auth.getSession();
      const loggedIn = !!session;
      setIsAuthenticated(loggedIn);
      
      if (loggedIn && session.user) {
        // Verificar si el usuario tiene rol de admin
        const { data: roleData, error } = await supabase
          .from('user_roles')
          .select('role')
          .eq('user_id', session.user.id)
          .eq('role', 'admin')
          .maybeSingle();
        
        const hasAdminRole = !error && roleData !== null;
        setIsAdmin(hasAdminRole);
        
        if (hasAdminRole) {
          loadPlaces();
        } else {
          toast({
            title: "Acceso denegado",
            description: "Solo los administradores pueden acceder a este panel",
            variant: "destructive",
          });
        }
      }
      setIsCheckingAuth(false);
    };
    init();

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      const loggedIn = !!session;
      setIsAuthenticated(loggedIn);
      
      if (loggedIn && session?.user) {
        setTimeout(async () => {
          const { data: roleData, error } = await supabase
            .from('user_roles')
            .select('role')
            .eq('user_id', session.user.id)
            .eq('role', 'admin')
            .maybeSingle();
          const hasAdminRole = !error && roleData !== null;
          setIsAdmin(hasAdminRole);
          if (hasAdminRole) {
            loadPlaces();
          }
        }, 0);
      } else {
        setIsAdmin(false);
      }
    });

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  const loadPlaces = async () => {
    try {
      const { data, error } = await supabase
        .from('places')
        .select('*')
        .order('localidad', { ascending: true });

      if (error) throw error;

      if (data) {
        // Convertir los datos de Supabase al formato del AdminPanel
        const formattedPlaces = data.map(place => ({
          id: place.id,
          nombre: place.nombre,
          tipo: place.tipo,
          subtipo: place.subtipo,
          localidad: place.localidad,
          direccion: place.direccion,
          telefono: place.telefono,
          latitud: place.latitud ? Number(place.latitud) : undefined,
          longitud: place.longitud ? Number(place.longitud) : undefined,
          imagenes: place.imagenes || [],
          imagen360URL: place.imagen_360_url,
          descripcion: place.descripcion || '',
          datosClave: place.datos_clave,
          categoriaAuspiciante: place.categoria_auspiciante || 0
        }));
        setPlaces(formattedPlaces);
      }
    } catch (error) {
      console.error('Error loading places:', error);
      toast({
        title: "Error",
        description: "No se pudieron cargar los lugares",
        variant: "destructive",
      });
    }
  };


  const handleAddPlace = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      // Obtener el máximo de imágenes permitidas según la categoría
      const maxImagenes = formData.categoriaAuspiciante === 3 ? 5 : 
                         formData.categoriaAuspiciante === 2 ? 3 : 
                         formData.categoriaAuspiciante === 1 ? 2 : 1;
      
      // Filtrar solo las URLs válidas y limitar según la categoría
      const imagenesValidas = formData.imagenes
        .filter(url => url.trim() !== '')
        .slice(0, maxImagenes);

      const placeData = {
        nombre: formData.nombre,
        tipo: formData.tipo,
        subtipo: formData.subtipo || null,
        localidad: formData.localidad,
        direccion: formData.direccion || null,
        telefono: formData.telefono || null,
        latitud: formData.latitud ? parseFloat(formData.latitud) : null,
        longitud: formData.longitud ? parseFloat(formData.longitud) : null,
        imagenes: imagenesValidas,
        imagen_360_url: formData.imagen360URL || null,
        descripcion: formData.descripcion || null,
        datos_clave: formData.datosClave || null,
        categoria_auspiciante: formData.categoriaAuspiciante
      };

      if (editingPlace) {
        // Actualizar lugar existente
        const { error } = await supabase
          .from('places')
          .update(placeData)
          .eq('id', editingPlace.id);

        if (error) throw error;

        setEditingPlace(null);
        toast({
          title: "Lugar actualizado",
          description: `${formData.nombre} ha sido actualizado exitosamente`,
        });
      } else {
        // Insertar nuevo lugar
        const { error } = await supabase
          .from('places')
          .insert([placeData]);

        if (error) throw error;

        toast({
          title: "Lugar agregado",
          description: `${formData.nombre} ha sido agregado exitosamente`,
        });
      }

      // Recargar lugares desde la base de datos
      await loadPlaces();

      // Reset form
      setFormData({
        tipo: "",
        subtipo: "",
        localidad: "",
        nombre: "",
        direccion: "",
        telefono: "",
        latitud: "",
        longitud: "",
        imagenes: ["", "", "", "", ""],
        imagen360URL: "",
        descripcion: "",
        datosClave: "",
        categoriaAuspiciante: 0
      });
    } catch (error) {
      console.error('Error saving place:', error);
      toast({
        title: "Error",
        description: "No se pudo guardar el lugar",
        variant: "destructive",
      });
    }
  };

  const handleEditPlace = (place: Place) => {
    setEditingPlace(place);
    const imagenesArray = [...(place.imagenes || []), "", "", "", "", ""].slice(0, 5);
    setFormData({
      tipo: place.tipo,
      subtipo: place.subtipo || "",
      localidad: place.localidad,
      nombre: place.nombre,
      direccion: place.direccion || "",
      telefono: place.telefono || "",
      latitud: place.latitud?.toString() || "",
      longitud: place.longitud?.toString() || "",
      imagenes: imagenesArray,
      imagen360URL: place.imagen360URL || "",
      descripcion: place.descripcion || "",
      datosClave: place.datosClave || "",
      categoriaAuspiciante: place.categoriaAuspiciante || 0
    });
    setActiveTab("add-single");
  };

  const handleDeletePlace = (id: string) => {
    setDeleteTarget(id);
    setDeleteType('place');
    setDeleteInfo({});
    setShowDeleteDialog(true);
  };

  const handleDeleteGroup = (localidad: string) => {
    setDeleteTarget(null);
    setDeleteType('group');
    setDeleteInfo({ localidad });
    setShowDeleteDialog(true);
  };

  const handleDeleteSubgroup = (localidad: string, tipo: string) => {
    setDeleteTarget(null);
    setDeleteType('subgroup');
    setDeleteInfo({ localidad, tipo });
    setShowDeleteDialog(true);
  };

  const confirmDelete = async () => {
    try {
      if (deleteType === 'place' && deleteTarget) {
        const { error } = await supabase
          .from('places')
          .delete()
          .eq('id', deleteTarget);

        if (error) throw error;

        toast({
          title: "Lugar eliminado",
          description: "El lugar ha sido eliminado exitosamente",
        });
      } else if (deleteType === 'group' && deleteInfo.localidad) {
        const { error } = await supabase
          .from('places')
          .delete()
          .eq('localidad', deleteInfo.localidad);

        if (error) throw error;

        const localidadLabel = localidades.find(l => l.value === deleteInfo.localidad)?.label || deleteInfo.localidad;
        toast({
          title: "Grupo eliminado",
          description: `Se eliminaron los lugares de ${localidadLabel}`,
        });
      } else if (deleteType === 'subgroup' && deleteInfo.localidad && deleteInfo.tipo) {
        const { error } = await supabase
          .from('places')
          .delete()
          .match({ localidad: deleteInfo.localidad, tipo: deleteInfo.tipo });

        if (error) throw error;

        const tipoLabel = tiposLugar.find(t => t.value === deleteInfo.tipo)?.label || deleteInfo.tipo;
        const localidadLabel = localidades.find(l => l.value === deleteInfo.localidad)?.label || deleteInfo.localidad;
        toast({
          title: "Subgrupo eliminado",
          description: `Se eliminaron lugares de ${tipoLabel} en ${localidadLabel}`,
        });
      }

      // Recargar lugares desde la base de datos
      await loadPlaces();
      
      setDeleteTarget(null);
      setDeleteInfo({});
      setShowDeleteDialog(false);
    } catch (error) {
      console.error('Error deleting:', error);
      toast({
        title: "Error",
        description: "No se pudo eliminar",
        variant: "destructive",
      });
    }
  };

  const processBulkData = async () => {
    const lines = bulkText.split('\n').filter(line => line.trim());
    let processed = 0;

    try {
      const placesToInsert = lines.map(line => {
        const parts = line.split(',');
        if (parts.length >= 4) {
          return {
            tipo: parts[0]?.trim() || "",
            nombre: parts[1]?.trim() || "",
            localidad: parts[2]?.trim() || "",
            direccion: parts[3]?.trim() || null,
            telefono: parts[4]?.trim() || null,
            latitud: parts[5] ? parseFloat(parts[5].trim()) : null,
            longitud: parts[6] ? parseFloat(parts[6].trim()) : null,
            descripcion: parts[7]?.trim() || null
          };
        }
        return null;
      }).filter(place => place !== null);

      const { error } = await supabase
        .from('places')
        .insert(placesToInsert);

      if (error) throw error;

      processed = placesToInsert.length;

      // Recargar lugares desde la base de datos
      await loadPlaces();

      setBulkText("");
      toast({
        title: "Carga masiva completada",
        description: `Se procesaron ${processed} lugares exitosamente`,
      });
    } catch (error) {
      console.error('Error in bulk insert:', error);
      toast({
        title: "Error",
        description: "No se pudo completar la carga masiva",
        variant: "destructive",
      });
    }
  };

  const exportData = () => {
    const dataStr = JSON.stringify(places, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'lugares_comarca_andina.json';
    link.click();
    toast({
      title: "Datos exportados",
      description: "Los datos han sido descargados exitosamente",
    });
  };

  const importData = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const { data: { session } } = await supabase.auth.getSession();
        if (!session) {
          toast({
            title: "Necesitas iniciar sesión",
            description: "Inicia sesión para poder importar y guardar datos",
            variant: "destructive",
          });
          return;
        }

        const raw = e.target?.result as string;
        const parsed = JSON.parse(raw);

        // Normalizador tolerante a distintos formatos (camelCase o snake_case)
        const normalize = (p: any, fallbackLocalidad?: string) => ({
          nombre: p.nombre,
          tipo: p.tipo,
          subtipo: p.subtipo ?? null,
          localidad: (p.localidad ?? fallbackLocalidad) ?? null,
          direccion: p.direccion ?? null,
          telefono: p.telefono ?? null,
          latitud: p.latitud != null ? parseFloat(String(p.latitud)) : null,
          longitud: p.longitud != null ? parseFloat(String(p.longitud)) : null,
          imagenes: Array.isArray(p.imagenes) ? p.imagenes : (p.imagen_url || p.imagenURL ? [p.imagen_url ?? p.imagenURL] : []),
          imagen_360_url: p.imagen_360_url ?? p.imagen360URL ?? null,
          descripcion: p.descripcion ?? null,
          datos_clave: p.datos_clave ?? p.datosClave ?? null,
          categoria_auspiciante: p.categoria_auspiciante ?? p.categoriaAuspiciante ?? (p.es_auspiciante ?? p.esAuspiciante ? 1 : 0),
        });

        let placesArray: any[] = [];

        if (Array.isArray(parsed)) {
          placesArray = parsed;
        } else if (Array.isArray(parsed?.places)) {
          placesArray = parsed.places;
        } else if (parsed && typeof parsed === 'object') {
          // Intentar aplanar objetos { "El Bolsón": [ ... ], "Cholila": [ ... ] }
          for (const [key, value] of Object.entries(parsed)) {
            if (Array.isArray(value)) {
              value.forEach((p: any) => placesArray.push({ ...p, localidad: p.localidad ?? key }));
            }
          }
        }

        if (!placesArray.length) {
          toast({
            title: "Formato no reconocido",
            description: "El JSON no contiene una lista de lugares reconocible",
            variant: "destructive",
          });
          return;
        }

        const placesToInsert = placesArray
          .map((p: any) => normalize(p))
          .filter((p) => p.nombre && p.tipo && p.localidad);

        if (!placesToInsert.length) {
          toast({
            title: "Datos insuficientes",
            description: "Faltan campos requeridos (nombre, tipo, localidad)",
            variant: "destructive",
          });
          return;
        }

        const { error } = await supabase
          .from('places')
          .insert(placesToInsert);

        if (error) throw error;

        await loadPlaces();
        toast({
          title: "Backup restaurado",
          description: `Se restauraron ${placesToInsert.length} lugares exitosamente`,
        });
      } catch (error: any) {
        console.error('Error importing data:', error);
        const msg = typeof error?.message === 'string' ? error.message : '';
        if (error?.code === '42501' || msg.includes('row-level security')) {
          toast({
            title: "Permisos requeridos",
            description: "Inicia sesión para poder importar (políticas de seguridad)",
            variant: "destructive",
          });
        } else if (msg.includes('JSON')) {
          toast({
            title: "JSON inválido",
            description: "Revisa el archivo. Debe ser un JSON válido",
            variant: "destructive",
          });
        } else {
          toast({
            title: "Error al importar",
            description: msg || "No se pudo procesar el archivo",
            variant: "destructive",
          });
        }
      }
    };
    reader.readAsText(file);
    // Reset input
    event.target.value = '';
  };

  // Mostrar loading mientras verificamos autenticación
  if (isCheckingAuth) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardContent className="py-8">
            <p className="text-center text-muted-foreground">Verificando permisos...</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Si no está autenticado, redirigir al login
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center space-y-2">
            <Shield className="w-12 h-12 mx-auto text-primary" />
            <CardTitle className="text-2xl">Acceso de Administrador</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-muted/50 p-4 rounded-lg border">
              <p className="text-sm text-muted-foreground text-center">
                Para acceder al panel de administración necesitas iniciar sesión con una cuenta autorizada.
              </p>
            </div>
            <div className="flex flex-col gap-2">
              <Button type="button" className="w-full" onClick={() => (window.location.href = '/auth')}>
                Iniciar Sesión
              </Button>
              <Button type="button" variant="outline" onClick={onBack} className="w-full">
                Volver al Inicio
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Si está autenticado pero no es admin, mostrar error
  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl text-destructive">Acceso Denegado</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground text-center">
              Solo los administradores tienen acceso a este panel.
            </p>
            <Button type="button" variant="outline" onClick={onBack} className="w-full">
              Volver al Inicio
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-gradient-hero text-white p-4 shadow-lg">
        <div className="container mx-auto flex items-center gap-4">
          <Button 
            variant="ghost" 
            size="icon"
            onClick={onBack}
            className="text-white hover:bg-white/10"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-xl font-semibold">Panel de Administración</h1>
            <p className="text-sm text-white/80">Gestión de contenido de la Comarca Andina</p>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8 max-w-6xl">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="add-single">
              <Plus className="w-4 h-4 mr-2" />
              Añadir Uno
            </TabsTrigger>
            <TabsTrigger value="bulk-add">
              <Upload className="w-4 h-4 mr-2" />
              Carga Rápida
            </TabsTrigger>
            <TabsTrigger value="manage">
              <Settings className="w-4 h-4 mr-2" />
              Gestionar
            </TabsTrigger>
            <TabsTrigger value="backup">
              <Database className="w-4 h-4 mr-2" />
              Backup
            </TabsTrigger>
          </TabsList>

          <TabsContent value="add-single" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>
                  {editingPlace ? "Editar Lugar" : "Añadir conocimiento a Andes"}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleAddPlace} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="tipo">Tipo de Lugar</Label>
                      <Select value={formData.tipo} onValueChange={(value) => setFormData({...formData, tipo: value})}>
                        <SelectTrigger>
                          <SelectValue placeholder="Selecciona el tipo" />
                        </SelectTrigger>
                        <SelectContent>
                          {tiposLugar.map((tipo) => (
                            <SelectItem key={tipo.value} value={tipo.value}>
                              {tipo.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="localidad">Localidad</Label>
                      <Select value={formData.localidad} onValueChange={(value) => setFormData({...formData, localidad: value})}>
                        <SelectTrigger>
                          <SelectValue placeholder="Selecciona la localidad" />
                        </SelectTrigger>
                        <SelectContent>
                          {localidades.map((loc) => (
                            <SelectItem key={loc.value} value={loc.value}>
                              {loc.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="nombre">Nombre del Lugar</Label>
                      <Input
                        id="nombre"
                        value={formData.nombre}
                        onChange={(e) => setFormData({...formData, nombre: e.target.value})}
                        required
                      />
                    </div>

                    <div>
                      <Label htmlFor="direccion">Dirección (Opcional)</Label>
                      <Input
                        id="direccion"
                        value={formData.direccion}
                        onChange={(e) => setFormData({...formData, direccion: e.target.value})}
                      />
                    </div>

                    <div>
                      <Label htmlFor="telefono">Teléfono (Opcional)</Label>
                      <Input
                        id="telefono"
                        value={formData.telefono}
                        onChange={(e) => setFormData({...formData, telefono: e.target.value})}
                      />
                    </div>

                    <div>
                      <Label htmlFor="latitud">Latitud (Opcional)</Label>
                      <Input
                        id="latitud"
                        type="number"
                        step="any"
                        value={formData.latitud}
                        onChange={(e) => setFormData({...formData, latitud: e.target.value})}
                        placeholder="-41.96"
                      />
                    </div>

                    <div>
                      <Label htmlFor="longitud">Longitud (Opcional)</Label>
                      <Input
                        id="longitud"
                        type="number"
                        step="any"
                        value={formData.longitud}
                        onChange={(e) => setFormData({...formData, longitud: e.target.value})}
                        placeholder="-71.53"
                      />
                    </div>

                    <div>
                      <Label htmlFor="imagen360URL">URL de Imagen 360° (Opcional)</Label>
                      <Input
                        id="imagen360URL"
                        type="url"
                        value={formData.imagen360URL}
                        onChange={(e) => setFormData({...formData, imagen360URL: e.target.value})}
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="descripcion">Descripción Principal (Opcional)</Label>
                    <Textarea
                      id="descripcion"
                      value={formData.descripcion}
                      onChange={(e) => setFormData({...formData, descripcion: e.target.value})}
                      rows={3}
                    />
                  </div>

                  <div>
                    <Label htmlFor="datosClave">Datos Clave / Puntos a Destacar (Opcional)</Label>
                    <Textarea
                      id="datosClave"
                      value={formData.datosClave}
                      onChange={(e) => setFormData({...formData, datosClave: e.target.value})}
                      rows={2}
                      placeholder="Horarios, precios, características especiales..."
                    />
                  </div>

                  <div className="space-y-3">
                    <Label>Categoría de Auspiciante</Label>
                    <Select 
                      value={formData.categoriaAuspiciante.toString()} 
                      onValueChange={(value) => setFormData({...formData, categoriaAuspiciante: parseInt(value)})}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="0">No es auspiciante</SelectItem>
                        <SelectItem value="1">⭐ Básico (1 estrella) - 2 imágenes</SelectItem>
                        <SelectItem value="2">⭐⭐ Premium (2 estrellas) - 3 imágenes</SelectItem>
                        <SelectItem value="3">⭐⭐⭐ Elite (3 estrellas) - 5 imágenes</SelectItem>
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-muted-foreground">
                      {formData.categoriaAuspiciante === 0 && "Este lugar no será destacado en las recomendaciones"}
                      {formData.categoriaAuspiciante === 1 && "Visibilidad básica, puede subir hasta 2 imágenes"}
                      {formData.categoriaAuspiciante === 2 && "Visibilidad premium, más recomendaciones, hasta 3 imágenes"}
                      {formData.categoriaAuspiciante === 3 && "Máxima visibilidad y prioridad en recomendaciones, hasta 5 imágenes"}
                    </p>
                  </div>

                  {formData.categoriaAuspiciante > 0 && (
                    <div className="space-y-3">
                      <Label>Imágenes del Lugar</Label>
                      {formData.imagenes.slice(0, 
                        formData.categoriaAuspiciante === 3 ? 5 : 
                        formData.categoriaAuspiciante === 2 ? 3 : 2
                      ).map((url, index) => (
                        <div key={index}>
                          <Label htmlFor={`imagen-${index}`} className="text-xs text-muted-foreground">
                            Imagen {index + 1} {index === 0 ? "(principal)" : "(opcional)"}
                          </Label>
                          <Input
                            id={`imagen-${index}`}
                            type="url"
                            value={url}
                            onChange={(e) => {
                              const newImagenes = [...formData.imagenes];
                              newImagenes[index] = e.target.value;
                              setFormData({...formData, imagenes: newImagenes});
                            }}
                            placeholder="https://ejemplo.com/imagen.jpg"
                          />
                        </div>
                      ))}
                    </div>
                  )}

                  <Button type="submit" className="w-full">
                    {editingPlace ? "Actualizar Lugar" : "Añadir Lugar"}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="bulk-add" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Carga Rápida</CardTitle>
                <p className="text-sm text-muted-foreground">
                  Pega cada lugar en una nueva línea. Separa cada dato con una coma.
                  Formato: Tipo, Nombre, Localidad, Dirección, Teléfono, Latitud, Longitud, Descripción
                </p>
              </CardHeader>
              <CardContent className="space-y-4">
                <Textarea
                  value={bulkText}
                  onChange={(e) => setBulkText(e.target.value)}
                  rows={10}
                  placeholder="restaurante, La Parrilla del Monte, El Bolsón, Av. San Martín 123, 02944-123456, -41.96, -71.53, Excelente parrilla con carnes patagónicas..."
                />
                <Button onClick={processBulkData} disabled={!bulkText.trim()}>
                  Procesar
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="manage" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Gestionar Contenido</CardTitle>
                <p className="text-sm text-muted-foreground">
                  Total de lugares: {places.length}
                </p>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {places.length === 0 ? (
                    <p className="text-center text-muted-foreground py-8">
                      No hay lugares agregados aún
                    </p>
                  ) : (
                    // Agrupar por localidades
                    Object.entries(
                      places.reduce((acc, place) => {
                        const localidadKey = place.localidad;
                        if (!acc[localidadKey]) {
                          acc[localidadKey] = [];
                        }
                        acc[localidadKey].push(place);
                        return acc;
                      }, {} as Record<string, Place[]>)
                    ).map(([localidadKey, placesInLocalidad]) => {
                      const localidadLabel = localidades.find(l => l.value === localidadKey)?.label || localidadKey;
                      const groupKey = `group-${localidadKey}`;
                      
                      return (
                        <Collapsible
                          key={localidadKey}
                          open={openGroups[groupKey] !== false}
                          onOpenChange={(open) => setOpenGroups(prev => ({ ...prev, [groupKey]: open }))}
                        >
                          <div className="border rounded-lg">
                            <CollapsibleTrigger className="w-full p-4 flex items-center justify-between hover:bg-muted/50 transition-colors">
                              <div className="flex items-center gap-2">
                                {openGroups[groupKey] !== false ? (
                                  <ChevronDown className="w-4 h-4" />
                                ) : (
                                  <ChevronRight className="w-4 h-4" />
                                )}
                                <h2 className="text-lg font-semibold">{localidadLabel}</h2>
                                <Badge variant="outline">{placesInLocalidad.length} lugares</Badge>
                              </div>
                              <div className="flex gap-2" onClick={(e) => e.stopPropagation()}>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => handleDeleteGroup(localidadKey)}
                                  className="text-destructive hover:text-destructive"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </Button>
                              </div>
                            </CollapsibleTrigger>
                            
                            <CollapsibleContent>
                              <div className="px-4 pb-4">
                                {/* Agrupar por tipos dentro de cada localidad */}
                                {Object.entries(
                                  placesInLocalidad.reduce((acc, place) => {
                                    const tipoKey = place.tipo;
                                    if (!acc[tipoKey]) {
                                      acc[tipoKey] = [];
                                    }
                                    acc[tipoKey].push(place);
                                    return acc;
                                  }, {} as Record<string, Place[]>)
                                ).map(([tipoKey, placesInTipo]) => {
                                  const tipoLabel = tiposLugar.find(t => t.value === tipoKey)?.label || tipoKey;
                                  const subgroupKey = `subgroup-${localidadKey}-${tipoKey}`;
                                  
                                  return (
                                    <Collapsible
                                      key={`${localidadKey}-${tipoKey}`}
                                      open={openSubgroups[subgroupKey] !== false}
                                      onOpenChange={(open) => setOpenSubgroups(prev => ({ ...prev, [subgroupKey]: open }))}
                                    >
                                      <div className="border rounded-md ml-4 mt-2">
                                        <CollapsibleTrigger className="w-full p-3 flex items-center justify-between hover:bg-muted/30 transition-colors">
                                          <div className="flex items-center gap-2">
                                            {openSubgroups[subgroupKey] !== false ? (
                                              <ChevronDown className="w-3 h-3" />
                                            ) : (
                                              <ChevronRight className="w-3 h-3" />
                                            )}
                                            <h3 className="font-medium">{tipoLabel}</h3>
                                            <Badge variant="secondary" className="text-xs">{placesInTipo.length}</Badge>
                                          </div>
                                          <div className="flex gap-2" onClick={(e) => e.stopPropagation()}>
                                            <Button
                                              size="sm"
                                              variant="outline"
                                              onClick={() => handleDeleteSubgroup(localidadKey, tipoKey)}
                                              className="text-destructive hover:text-destructive h-8 w-8 p-0"
                                            >
                                              <Trash2 className="w-3 h-3" />
                                            </Button>
                                          </div>
                                        </CollapsibleTrigger>
                                        
                                        <CollapsibleContent>
                                          <div className="px-3 pb-3">
                                            {/* Lista de establecimientos */}
                                            {placesInTipo.map((place) => (
                                              <div key={place.id} className="flex items-center justify-between p-3 border rounded ml-2 mt-2 bg-background/50">
                                                <div className="flex-1">
                                                  <div className="flex items-center gap-2 mb-1">
                                                    <h4 className="font-medium text-sm">{place.nombre}</h4>
                                                    {place.categoriaAuspiciante > 0 && (
                                                      <Badge variant="secondary" className="text-xs">
                                                        {place.categoriaAuspiciante === 1 && "⭐"}
                                                        {place.categoriaAuspiciante === 2 && "⭐⭐"}
                                                        {place.categoriaAuspiciante === 3 && "⭐⭐⭐"}
                                                      </Badge>
                                                    )}
                                                  </div>
                                                  <p className="text-xs text-muted-foreground line-clamp-1">{place.descripcion}</p>
                                                  {place.direccion && (
                                                    <p className="text-xs text-muted-foreground">{place.direccion}</p>
                                                  )}
                                                </div>
                                                <div className="flex gap-1">
                                                  <Button
                                                    size="sm"
                                                    variant="outline"
                                                    onClick={() => handleEditPlace(place)}
                                                    className="h-8 w-8 p-0"
                                                  >
                                                    <Edit className="w-3 h-3" />
                                                  </Button>
                                                  <Button
                                                    size="sm"
                                                    variant="outline"
                                                    onClick={() => handleDeletePlace(place.id)}
                                                    className="h-8 w-8 p-0 text-destructive hover:text-destructive"
                                                  >
                                                    <Trash2 className="w-3 h-3" />
                                                  </Button>
                                                </div>
                                              </div>
                                            ))}
                                          </div>
                                        </CollapsibleContent>
                                      </div>
                                    </Collapsible>
                                  );
                                })}
                              </div>
                            </CollapsibleContent>
                          </div>
                        </Collapsible>
                      );
                    })
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="backup" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Backup y Restauración</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button onClick={exportData} className="w-full">
                  <Download className="w-4 h-4 mr-2" />
                  Descargar Backup de Datos
                </Button>
                <div className="text-center text-sm text-muted-foreground">
                  Se descargará un archivo JSON con todos los lugares
                </div>
                
                <div className="border-t pt-4">
                  <Label htmlFor="backup-upload" className="cursor-pointer">
                    <Button variant="outline" className="w-full" asChild>
                      <span>
                        <Upload className="w-4 h-4 mr-2" />
                        Restaurar Backup
                      </span>
                    </Button>
                  </Label>
                  <input
                    id="backup-upload"
                    type="file"
                    accept=".json"
                    onChange={importData}
                    className="hidden"
                  />
                  <div className="text-center text-sm text-muted-foreground mt-2">
                    Selecciona un archivo JSON de backup para restaurar los datos
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmar Eliminación</AlertDialogTitle>
            <AlertDialogDescription>
              {deleteType === 'place' && "¿Estás seguro de que quieres eliminar este lugar? Esta acción no se puede deshacer."}
              {deleteType === 'group' && `¿Estás seguro de que quieres eliminar todos los lugares de ${localidades.find(l => l.value === deleteInfo.localidad)?.label || deleteInfo.localidad}? Esta acción no se puede deshacer.`}
              {deleteType === 'subgroup' && `¿Estás seguro de que quieres eliminar todos los lugares de tipo ${tiposLugar.find(t => t.value === deleteInfo.tipo)?.label || deleteInfo.tipo} en ${localidades.find(l => l.value === deleteInfo.localidad)?.label || deleteInfo.localidad}? Esta acción no se puede deshacer.`}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Eliminar
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};