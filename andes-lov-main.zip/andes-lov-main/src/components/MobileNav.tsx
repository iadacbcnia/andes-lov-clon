import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Drawer,
  DrawerContent,
  DrawerHeader,
  DrawerTitle,
  DrawerTrigger,
} from "@/components/ui/drawer";
import { Menu, Home, MessageCircle, Calendar, Map, Settings, Mountain } from "lucide-react";
import { RadioPlayer } from "./RadioPlayer";

interface MobileNavProps {
  activeView: string;
  onViewChange: (view: "home" | "chat" | "planner" | "map" | "admin") => void;
}

export const MobileNav = ({ activeView, onViewChange }: MobileNavProps) => {
  const [isOpen, setIsOpen] = useState(false);

  const menuItems = [
    {
      id: "home",
      label: "Inicio",
      icon: Home,
      description: "Página principal"
    },
    {
      id: "chat",
      label: "Asistente IA",
      icon: MessageCircle,
      description: "Habla con Andes"
    },
    {
      id: "planner",
      label: "Planificador",
      icon: Calendar,
      description: "Crea tu itinerario"
    },
    {
      id: "map",
      label: "Mapa",
      icon: Map,
      description: "Explora la región"
    },
    {
      id: "admin",
      label: "Gestión",
      icon: Settings,
      description: "Panel de control"
    }
  ];

  const handleMenuClick = (viewId: string) => {
    onViewChange(viewId as "home" | "chat" | "planner" | "map" | "admin");
    setIsOpen(false);
  };

  return (
    <>
      {/* Mobile Menu Button - Fixed position */}
      <div className="fixed top-4 right-4 z-50 md:hidden">
        <Drawer open={isOpen} onOpenChange={setIsOpen}>
          <DrawerTrigger asChild>
            <Button 
              size="icon" 
              className="rounded-full bg-primary/90 hover:bg-primary shadow-mountain backdrop-blur-sm"
            >
              <Menu className="w-5 h-5" />
            </Button>
          </DrawerTrigger>
          <DrawerContent className="h-[85vh] bg-background/95 backdrop-blur-lg border-t-2 border-primary/20">
            <DrawerHeader className="text-center border-b border-border/50">
              <div className="flex items-center justify-center space-x-2 mb-2">
                <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                  <Mountain className="w-4 h-4 text-primary" />
                </div>
                <DrawerTitle className="text-xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                  Andes
                </DrawerTitle>
              </div>
              <p className="text-sm text-muted-foreground">Tu guía en la Comarca Andina</p>
            </DrawerHeader>
            
            <div className="flex-1 p-6 space-y-6">
              {/* Radio Player */}
              <div className="space-y-3">
                <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wide">
                  Radio en vivo
                </h3>
                <RadioPlayer />
              </div>

              {/* Navigation Menu */}
              <div className="space-y-3">
                <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wide">
                  Navegación
                </h3>
                <div className="grid gap-3">
                  {menuItems.map((item) => (
                    <Button
                      key={item.id}
                      variant={activeView === item.id ? "default" : "ghost"}
                      className={`h-auto p-4 justify-start text-left transition-all duration-200 ${
                        activeView === item.id 
                          ? "bg-primary text-primary-foreground shadow-md" 
                          : "hover:bg-muted hover:shadow-sm"
                      }`}
                      onClick={() => handleMenuClick(item.id)}
                    >
                      <item.icon className={`w-5 h-5 mr-3 ${
                        activeView === item.id ? "text-primary-foreground" : "text-primary"
                      }`} />
                      <div className="flex-1">
                        <div className="font-medium">{item.label}</div>
                        <div className={`text-xs ${
                          activeView === item.id ? "text-primary-foreground/80" : "text-muted-foreground"
                        }`}>
                          {item.description}
                        </div>
                      </div>
                    </Button>
                  ))}
                </div>
              </div>

              {/* Footer */}
              <div className="pt-6 border-t border-border/50">
                <p className="text-xs text-center text-muted-foreground">
                  Paralelo 42 - Patagonia Argentina
                </p>
              </div>
            </div>
          </DrawerContent>
        </Drawer>
      </div>

      {/* Desktop Header with Radio */}
      <div className="hidden md:flex fixed top-0 left-0 right-0 z-40 bg-background/80 backdrop-blur-lg border-b border-border/50">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Button
              variant="ghost"
              onClick={() => onViewChange("home")}
              className="text-lg font-bold text-primary hover:text-primary/80"
            >
              <Mountain className="w-6 h-6 mr-2" />
              Andes
            </Button>
          </div>
          
            <div className="flex items-center space-x-6">
            <nav className="flex items-center space-x-2">
              {menuItems.slice(0, 4).map((item) => (
                <Button
                  key={item.id}
                  variant={activeView === item.id ? "default" : "ghost"}
                  size="sm"
                  onClick={() => onViewChange(item.id as any)}
                  className="text-sm"
                >
                  <item.icon className="w-4 h-4 mr-2" />
                  {item.label}
                </Button>
              ))}
            </nav>
          </div>
        </div>
      </div>
    </>
  );
};