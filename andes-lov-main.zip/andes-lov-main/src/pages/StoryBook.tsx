import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { toast } from "sonner";
import { Upload, Trash2, ArrowLeft, BookOpen, Download, Share2, ChevronLeft, ChevronRight } from "lucide-react";
import { User } from "@supabase/supabase-js";
import { VoiceInput } from "@/components/VoiceInput";
import { useIsMobile } from "@/hooks/use-mobile";
import jsPDF from "jspdf";
import { canUseFeature, incrementUsage, getRemainingUses } from "@/lib/usage-limits";

interface PhotoItem {
  id: string;
  file: File;
  preview: string;
}

interface Question {
  id: number;
  text: string;
  answer: string;
}

export default function StoryBook() {
  const navigate = useNavigate();
  const isMobile = useIsMobile();
  const [user, setUser] = useState<User | null>(null);
  const [photos, setPhotos] = useState<PhotoItem[]>([]);
  const [step, setStep] = useState<"upload" | "questions" | "generating" | "book">("upload");
  const [questions] = useState<Question[]>([
    { id: 1, text: "¿Qué fue lo más memorable de tu viaje?", answer: "" },
    { id: 2, text: "¿Con quién compartiste esta experiencia?", answer: "" },
    { id: 3, text: "¿Qué emoción describe mejor tu viaje?", answer: "" },
  ]);
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [additionalInfo, setAdditionalInfo] = useState("");
  const [story, setStory] = useState<Array<{ image: string; text: string }>>([]);
  const [currentPage, setCurrentPage] = useState(0);
  const [isGenerating, setIsGenerating] = useState(false);

  useEffect(() => {
    checkUser();
  }, []);

  const checkUser = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      toast.error("Debes iniciar sesión");
      navigate("/auth");
      return;
    }
    setUser(user);
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    addPhotos(files);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const files = Array.from(e.dataTransfer.files);
    addPhotos(files);
  };

  const addPhotos = (files: File[]) => {
    if (photos.length + files.length > 4) {
      toast.error("Máximo 4 fotos permitidas");
      return;
    }

    const validFiles = files.filter(f => f.type.startsWith("image/"));
    if (validFiles.length !== files.length) {
      toast.error("Solo se permiten imágenes");
    }

    const newPhotos = validFiles.map(file => ({
      id: Math.random().toString(36),
      file,
      preview: URL.createObjectURL(file),
    }));

    setPhotos(prev => [...prev, ...newPhotos]);
    toast.success(`${newPhotos.length} foto(s) agregada(s)`);
  };

  const removePhoto = (id: string) => {
    setPhotos(prev => {
      const photo = prev.find(p => p.id === id);
      if (photo) URL.revokeObjectURL(photo.preview);
      return prev.filter(p => p.id !== id);
    });
    toast.success("Foto eliminada");
  };

  const compressImage = (file: File): Promise<string> => {
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const img = new Image();
        img.onload = () => {
          const canvas = document.createElement('canvas');
          const MAX_WIDTH = 800;
          const MAX_HEIGHT = 800;
          let width = img.width;
          let height = img.height;

          if (width > height) {
            if (width > MAX_WIDTH) {
              height *= MAX_WIDTH / width;
              width = MAX_WIDTH;
            }
          } else {
            if (height > MAX_HEIGHT) {
              width *= MAX_HEIGHT / height;
              height = MAX_HEIGHT;
            }
          }

          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          ctx?.drawImage(img, 0, 0, width, height);
          
          resolve(canvas.toDataURL('image/jpeg', 0.7));
        };
        img.src = e.target?.result as string;
      };
      reader.readAsDataURL(file);
    });
  };

  const handleGenerateStory = async () => {
    if (photos.length === 0) {
      toast.error("Agrega al menos una foto");
      return;
    }

    const unanswered = questions.filter(q => !answers[q.id]?.trim());
    if (unanswered.length > 0) {
      toast.error("Por favor responde todas las preguntas");
      return;
    }

    // Verificar límite de uso
    if (!canUseFeature('storybook')) {
      toast.error(`Has usado tus ${getRemainingUses('storybook')} storybooks diarios. Vuelve mañana.`);
      return;
    }

    setIsGenerating(true);
    setStep("generating");

    try {
      // Compress and convert photos to base64
      toast.info("Preparando imágenes...");
      const photosBase64 = await Promise.all(
        photos.map(photo => compressImage(photo.file))
      );

      toast.info("Generando tu historia...");
      const { data, error } = await supabase.functions.invoke("generate-storybook", {
        body: {
          photos: photosBase64,
          answers: questions.map(q => ({ question: q.text, answer: answers[q.id] })),
          additionalInfo: additionalInfo || null,
        },
      });

      if (error) {
        console.error("Supabase error:", error);
        throw new Error("Error de conexión. Por favor intenta de nuevo.");
      }

      if (data?.error) {
        console.error("Function error:", data.error);
        if (data.error.includes("503") || data.error.includes("unavailable")) {
          throw new Error("El servicio de IA está temporalmente saturado. Por favor intenta en unos minutos.");
        }
        throw new Error(data.error);
      }

      if (!data?.story || data.story.length === 0) {
        throw new Error("No se pudo generar la historia. Por favor intenta de nuevo.");
      }

      setStory(data.story);
      setStep("book");
      
      // Incrementar contador solo si fue exitoso
      incrementUsage('storybook');
      toast.success("¡Storybook generado!");
    } catch (error: any) {
      console.error("Error completo:", error);
      toast.error(error.message || "Error al generar el storybook. Intenta nuevamente.");
      setStep("questions");
    } finally {
      setIsGenerating(false);
    }
  };

  const handleDownloadPDF = async () => {
    if (!story || story.length === 0) {
      toast.error("No hay historia para descargar");
      return;
    }

    toast.info("Generando PDF...");

    try {
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4'
      });

      const pageWidth = pdf.internal.pageSize.getWidth();
      const pageHeight = pdf.internal.pageSize.getHeight();
      const margin = 15;
      const contentWidth = pageWidth - (margin * 2);

      for (let i = 0; i < story.length; i++) {
        if (i > 0) {
          pdf.addPage();
        }

        // Add page number
        pdf.setFontSize(10);
        pdf.setTextColor(150);
        pdf.text(`Página ${i + 1} de ${story.length}`, pageWidth / 2, margin / 2, { align: 'center' });

        // Add image
        try {
          const img = new Image();
          img.crossOrigin = 'anonymous';
          await new Promise((resolve, reject) => {
            img.onload = resolve;
            img.onerror = reject;
            img.src = story[i].image;
          });

          const imgWidth = contentWidth;
          const imgHeight = (img.height * imgWidth) / img.width;
          const maxImgHeight = pageHeight * 0.5;
          const finalImgHeight = Math.min(imgHeight, maxImgHeight);
          const finalImgWidth = (img.width * finalImgHeight) / img.height;

          pdf.addImage(
            img,
            'JPEG',
            (pageWidth - finalImgWidth) / 2,
            margin + 10,
            finalImgWidth,
            finalImgHeight
          );

          // Add text
          pdf.setFontSize(11);
          pdf.setTextColor(60);
          const textY = margin + 15 + finalImgHeight + 10;
          const lines = pdf.splitTextToSize(story[i].text, contentWidth);
          pdf.text(lines, margin, textY);

        } catch (error) {
          console.error('Error adding image to PDF:', error);
        }
      }

      pdf.save('mi-storybook.pdf');
      toast.success("PDF descargado exitosamente");
    } catch (error) {
      console.error('Error generating PDF:', error);
      toast.error("Error al generar el PDF");
    }
  };

  const handleShareWhatsApp = async () => {
    if (!story || story.length === 0) {
      toast.error("No hay historia para compartir");
      return;
    }

    toast.info("Descargando PDF para compartir...");
    
    try {
      // Primero descargar el PDF
      await handleDownloadPDF();
      
      // Luego abrir WhatsApp con instrucciones
      setTimeout(() => {
        const text = encodeURIComponent("¡Mira mi Storybook de viaje creado con Andes! 📖✨\n\n(Adjunta el archivo PDF que acabo de descargar)");
        window.open(`https://wa.me/?text=${text}`, "_blank");
      }, 1000);
    } catch (error) {
      toast.error("Error al preparar el archivo para compartir");
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/20 p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <Button variant="ghost" onClick={() => navigate("/")}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Volver
          </Button>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <BookOpen className="h-8 w-8" />
            Storybook con IA
          </h1>
          <div className="w-24" />
        </div>

        {/* Upload Step */}
        {step === "upload" && (
          <div className="space-y-6">
            <Card className="p-8">
              <h2 className="text-2xl font-semibold mb-4">Sube tus fotos de viaje</h2>
              <p className="text-muted-foreground mb-6">
                Carga hasta 4 fotos. Puedes arrastrarlas o seleccionarlas.
              </p>

              <div
                onDrop={handleDrop}
                onDragOver={(e) => e.preventDefault()}
                className="border-2 border-dashed border-primary/30 rounded-lg p-12 text-center hover:border-primary/60 transition-colors cursor-pointer"
                onClick={() => document.getElementById("file-input")?.click()}
              >
                <Upload className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                <p className="text-lg mb-2">Arrastra las fotos aquí</p>
                <p className="text-sm text-muted-foreground">o haz clic para seleccionar</p>
                <input
                  id="file-input"
                  type="file"
                  multiple
                  accept="image/*"
                  className="hidden"
                  onChange={handleFileSelect}
                />
              </div>

              {photos.length > 0 && (
                <div className="mt-6">
                  <p className="font-medium mb-4">{photos.length}/4 fotos</p>
                  <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                    {photos.map((photo) => (
                      <div key={photo.id} className="relative group">
                        <img
                          src={photo.preview}
                          alt="Preview"
                          className="w-full h-32 object-cover rounded-lg"
                        />
                        <button
                          onClick={() => removePhoto(photo.id)}
                          className="absolute top-2 right-2 bg-destructive text-destructive-foreground p-2 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </Card>

            <div className="flex justify-end">
              <Button
                size="lg"
                onClick={() => setStep("questions")}
                disabled={photos.length === 0}
              >
                Continuar
              </Button>
            </div>
          </div>
        )}

        {/* Questions Step */}
        {step === "questions" && (
          <div className="space-y-6">
            <Card className="p-8">
              <h2 className="text-2xl font-semibold mb-6">Cuéntame sobre tu viaje</h2>

              <div className="space-y-6">
                {questions.map((q) => (
                  <div key={q.id}>
                    <label className="block font-medium mb-2">{q.text}</label>
                    <div className="relative">
                      <Textarea
                        value={answers[q.id] || ""}
                        onChange={(e) => setAnswers({ ...answers, [q.id]: e.target.value })}
                        placeholder="Tu respuesta... (o usa el micrófono)"
                        className="min-h-[100px] pr-12"
                      />
                      <div className="absolute right-2 bottom-2">
                        <VoiceInput 
                          onTranscript={(text) => setAnswers({ ...answers, [q.id]: (answers[q.id] || "") + " " + text })}
                        />
                      </div>
                    </div>
                  </div>
                ))}

                <div>
                  <label className="block font-medium mb-2">
                    ¿Algo más que quieras agregar? (Opcional)
                  </label>
                  <div className="relative">
                    <Textarea
                      value={additionalInfo}
                      onChange={(e) => setAdditionalInfo(e.target.value)}
                      placeholder="Detalles adicionales... (o usa el micrófono)"
                      className="min-h-[120px] pr-12"
                    />
                    <div className="absolute right-2 bottom-2">
                      <VoiceInput 
                        onTranscript={(text) => setAdditionalInfo(additionalInfo + " " + text)}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </Card>

            <div className="flex justify-between">
              <Button variant="outline" onClick={() => setStep("upload")}>
                Volver
              </Button>
              <Button size="lg" onClick={handleGenerateStory}>
                Generar Storybook
              </Button>
            </div>
          </div>
        )}

        {/* Generating Step */}
        {step === "generating" && (
          <Card className="p-12 text-center">
            <BookOpen className="h-16 w-16 mx-auto mb-4 animate-pulse" />
            <h2 className="text-2xl font-semibold mb-2">Andes está creando tu historia...</h2>
            <p className="text-muted-foreground">Analizando tus fotos y respuestas</p>
          </Card>
        )}

        {/* Book Step */}
        {step === "book" && story.length > 0 && (
          <div className="space-y-4">
            {/* Action Buttons */}
            <div className="flex justify-between items-center">
              <Button variant="outline" size={isMobile ? "sm" : "default"} onClick={() => setStep("upload")}>
                Crear otro
              </Button>
              <div className="flex gap-2">
                <Button variant="outline" size={isMobile ? "sm" : "default"} onClick={handleDownloadPDF}>
                  <Download className="h-4 w-4 md:mr-2" />
                  <span className="hidden md:inline">PDF</span>
                </Button>
                <Button size={isMobile ? "sm" : "default"} onClick={handleShareWhatsApp}>
                  <Share2 className="h-4 w-4 md:mr-2" />
                  <span className="hidden md:inline">WhatsApp</span>
                </Button>
              </div>
            </div>

            {/* Mobile View - Full Page Story */}
            {isMobile ? (
              <div className="relative">
                {/* Full Screen Story Page */}
                <div className="relative min-h-[85vh] rounded-2xl overflow-hidden shadow-2xl bg-card">
                  {/* Background Image with Overlay */}
                  <div className="absolute inset-0">
                    <img
                      src={story[currentPage]?.image}
                      alt={`Page ${currentPage + 1}`}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-black/60 to-black/80" />
                  </div>

                  {/* Content */}
                  <div className="relative h-full flex flex-col">
                    {/* Image Section - Top 60% */}
                    <div className="flex-[3] flex items-center justify-center p-4 pt-8">
                      <img
                        src={story[currentPage]?.image}
                        alt={`Page ${currentPage + 1}`}
                        className="max-h-full w-full object-contain rounded-xl shadow-2xl ring-4 ring-white/20"
                      />
                    </div>

                    {/* Text Section - Bottom 40% */}
                    <div className="flex-[2] bg-gradient-to-b from-background/95 to-background p-6 rounded-t-3xl -mt-6 shadow-[0_-10px_40px_rgba(0,0,0,0.3)]">
                      <div className="max-h-full overflow-y-auto">
                        <p className="text-base leading-relaxed whitespace-pre-wrap text-foreground/90 font-light tracking-wide">
                          {story[currentPage]?.text}
                        </p>
                      </div>
                      
                      {/* Page Number Badge */}
                      <div className="flex justify-center mt-4">
                        <div className="bg-primary/10 backdrop-blur-sm px-4 py-2 rounded-full">
                          <span className="text-sm font-medium text-primary">
                            Página {currentPage + 1} de {story.length}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Navigation Arrows - Floating */}
                <div className="absolute inset-y-0 left-0 right-0 flex items-center justify-between pointer-events-none px-2">
                  <Button
                    variant="secondary"
                    size="icon"
                    className="pointer-events-auto h-12 w-12 rounded-full bg-background/90 backdrop-blur-sm shadow-xl disabled:opacity-30"
                    onClick={() => setCurrentPage(Math.max(0, currentPage - 1))}
                    disabled={currentPage === 0}
                  >
                    <ChevronLeft className="h-6 w-6" />
                  </Button>
                  <Button
                    variant="secondary"
                    size="icon"
                    className="pointer-events-auto h-12 w-12 rounded-full bg-background/90 backdrop-blur-sm shadow-xl disabled:opacity-30"
                    onClick={() => setCurrentPage(Math.min(story.length - 1, currentPage + 1))}
                    disabled={currentPage === story.length - 1}
                  >
                    <ChevronRight className="h-6 w-6" />
                  </Button>
                </div>
              </div>
            ) : (
              /* Desktop View - Book Layout */
              <div className="relative perspective-1000">
                <div className="flex justify-center items-center min-h-[600px]">
                  <div className="relative w-full max-w-4xl">
                    {/* Current Spread */}
                    <div className="grid grid-cols-2 gap-4 bg-background rounded-lg shadow-2xl p-8">
                      {/* Left Page - Image */}
                      <div className="flex items-center justify-center bg-muted/30 rounded-lg p-6">
                        <img
                          src={story[currentPage]?.image}
                          alt={`Page ${currentPage + 1}`}
                          className="max-w-full max-h-[500px] object-contain rounded-lg shadow-lg"
                        />
                      </div>

                      {/* Right Page - Text */}
                      <div className="flex items-center justify-center p-6">
                        <div className="prose prose-lg max-w-none">
                          <p className="text-lg leading-relaxed whitespace-pre-wrap">
                            {story[currentPage]?.text}
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Navigation */}
                    <div className="flex justify-center items-center gap-4 mt-6">
                      <Button
                        variant="outline"
                        onClick={() => setCurrentPage(Math.max(0, currentPage - 1))}
                        disabled={currentPage === 0}
                      >
                        ← Anterior
                      </Button>
                      <span className="text-sm text-muted-foreground">
                        Página {currentPage + 1} de {story.length}
                      </span>
                      <Button
                        variant="outline"
                        onClick={() => setCurrentPage(Math.min(story.length - 1, currentPage + 1))}
                        disabled={currentPage === story.length - 1}
                      >
                        Siguiente →
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
