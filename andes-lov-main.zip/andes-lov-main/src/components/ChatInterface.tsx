import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { ArrowLeft, Send, Mountain, User, Mic, MicOff, Star, MapPin } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { searchPlaces, getPlacesByType, getPlacesByLocation, type Place } from "@/lib/supabase";
import { PlaceReviews } from "./PlaceReviews";
import { canUseFeature, incrementUsage, getRemainingUses } from "@/lib/usage-limits";

interface Message {
  id: string;
  text: string;
  sender: "user" | "ai";
  timestamp: Date;
  isSponsored?: boolean;
  imageUrl?: string;
  places?: Place[];
}

interface ChatInterfaceProps {
  onBack: () => void;
  onOpenMap: (place: { id: string; name: string; description?: string; latitude?: number; longitude?: number }) => void;
  persistedMessages?: Message[];
  onPersistMessages?: (messages: Message[]) => void;
}

export const ChatInterface = ({ onBack, onOpenMap, persistedMessages, onPersistMessages }: ChatInterfaceProps) => {
  const defaultWelcome: Message = {
    id: "welcome",
    text: "¡Hola! Soy Andes, tu asistente personal de la Comarca Andina. Estoy aquí para ayudarte a descubrir los mejores lugares, actividades y secretos de esta hermosa región. ¿En qué puedo ayudarte hoy?",
    sender: "ai",
    timestamp: new Date()
  };
  const [localMessages, setLocalMessages] = useState<Message[]>([defaultWelcome]);
  const messages = persistedMessages ?? localMessages;
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [selectedPlace, setSelectedPlace] = useState<{ id: string; name: string } | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  const getCurrentMessages = () => (persistedMessages ?? localMessages);

  const updateMessages = (updater: (prev: Message[]) => Message[]) => {
    if (onPersistMessages) {
      const base = getCurrentMessages();
      const next = updater(base);
      onPersistMessages(next);
      setLocalMessages(next);
    } else {
      setLocalMessages(updater);
    }
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const analyzeQuery = (query: string) => {
    const lowerQuery = query.toLowerCase();
    
    // Detectar preguntas sobre clima
    if (lowerQuery.includes('clima') || lowerQuery.includes('tiempo') || 
        lowerQuery.includes('temperatura') || lowerQuery.includes('pronóstico') || 
        lowerQuery.includes('pronostico') || lowerQuery.includes('lluvia') ||
        lowerQuery.includes('frío') || lowerQuery.includes('frio') ||
        lowerQuery.includes('calor') || lowerQuery.includes('nieve')) {
      return { type: 'weather', location: extractLocation(lowerQuery) };
    }
    
    // Detectar tipo de lugar
    if (lowerQuery.includes('cabaña') || lowerQuery.includes('cabañas')) {
      return { type: 'cabañas', location: extractLocation(lowerQuery) };
    }
    if (lowerQuery.includes('restaurant') || lowerQuery.includes('comer') || lowerQuery.includes('comida')) {
      return { type: 'restaurante', location: extractLocation(lowerQuery) };
    }
    if (lowerQuery.includes('hotel') || lowerQuery.includes('hosped') || lowerQuery.includes('dormir')) {
      return { type: 'hotel', location: extractLocation(lowerQuery) };
    }
    if (lowerQuery.includes('actividad') || lowerQuery.includes('hacer') || lowerQuery.includes('turismo')) {
      return { type: 'actividad', location: extractLocation(lowerQuery) };
    }
    
    // Detectar ubicación específica
    const location = extractLocation(lowerQuery);
    if (location) {
      return { type: 'general', location };
    }
    
    return { type: 'general', location: null };
  };

  const extractLocation = (query: string) => {
    const locations = [
      'el bolsón', 'bolsón', 
      'el hoyo', 'hoyo', 
      'lago puelo', 'puelo', 
      'epuyén', 'epuyen',
      'cholila',
      'el maitén', 'maiten',
      'bariloche',
      'esquel'
    ];
    for (const location of locations) {
      if (query.includes(location)) {
        return location;
      }
    }
    return null;
  };

  const getWeatherData = async (location: string | null) => {
    try {
      // Mapeo de ubicaciones a coordenadas
      const locationCoords: { [key: string]: { lat: number; lon: number; name: string } } = {
        'el bolsón': { lat: -41.9628, lon: -71.5328, name: 'El Bolsón' },
        'bolsón': { lat: -41.9628, lon: -71.5328, name: 'El Bolsón' },
        'el hoyo': { lat: -42.0667, lon: -71.5167, name: 'El Hoyo' },
        'hoyo': { lat: -42.0667, lon: -71.5167, name: 'El Hoyo' },
        'lago puelo': { lat: -42.0667, lon: -71.6000, name: 'Lago Puelo' },
        'puelo': { lat: -42.0667, lon: -71.6000, name: 'Lago Puelo' },
        'epuyén': { lat: -42.1167, lon: -71.4000, name: 'Epuyén' },
        'epuyen': { lat: -42.1167, lon: -71.4000, name: 'Epuyén' },
        'cholila': { lat: -42.5167, lon: -71.4500, name: 'Cholila' },
        'el maitén': { lat: -42.0500, lon: -71.1667, name: 'El Maitén' },
        'maiten': { lat: -42.0500, lon: -71.1667, name: 'El Maitén' },
        'bariloche': { lat: -41.1335, lon: -71.3103, name: 'Bariloche' },
        'esquel': { lat: -42.9114, lon: -71.3194, name: 'Esquel' }
      };

      const locationKey = location?.toLowerCase() || 'el bolsón';
      const coords = locationCoords[locationKey] || locationCoords['el bolsón'];

      // Usar Open-Meteo API (100% gratuita, sin API key)
      const weatherUrl = `https://api.open-meteo.com/v1/forecast?latitude=${coords.lat}&longitude=${coords.lon}&current=temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,wind_speed_10m&daily=weather_code,temperature_2m_max,temperature_2m_min&timezone=America/Argentina/Buenos_Aires&forecast_days=5`;

      const response = await fetch(weatherUrl);

      if (!response.ok) {
        throw new Error('Error al obtener datos del clima');
      }

      const data = await response.json();

      // Códigos de clima de Open-Meteo a descripciones en español
      const getWeatherDescription = (code: number): string => {
        const descriptions: { [key: number]: string } = {
          0: 'Despejado',
          1: 'Mayormente despejado',
          2: 'Parcialmente nublado',
          3: 'Nublado',
          45: 'Niebla',
          48: 'Niebla con escarcha',
          51: 'Llovizna ligera',
          53: 'Llovizna moderada',
          55: 'Llovizna intensa',
          61: 'Lluvia ligera',
          63: 'Lluvia moderada',
          65: 'Lluvia intensa',
          71: 'Nevada ligera',
          73: 'Nevada moderada',
          75: 'Nevada intensa',
          77: 'Granizo',
          80: 'Chubascos ligeros',
          81: 'Chubascos moderados',
          82: 'Chubascos intensos',
          85: 'Chubascos de nieve ligeros',
          86: 'Chubascos de nieve intensos',
          95: 'Tormenta',
          96: 'Tormenta con granizo ligero',
          99: 'Tormenta con granizo intenso'
        };
        return descriptions[code] || 'Desconocido';
      };

      return {
        location: coords.name,
        current: {
          temp: Math.round(data.current.temperature_2m),
          feels_like: Math.round(data.current.apparent_temperature),
          humidity: data.current.relative_humidity_2m,
          description: getWeatherDescription(data.current.weather_code),
          wind_speed: Math.round(data.current.wind_speed_10m),
          precipitation: data.current.precipitation
        },
        forecast: data.daily.time.map((date: string, index: number) => ({
          date: new Date(date),
          temp_min: Math.round(data.daily.temperature_2m_min[index]),
          temp_max: Math.round(data.daily.temperature_2m_max[index]),
          description: getWeatherDescription(data.daily.weather_code[index])
        }))
      };
    } catch (error) {
      console.error('Error fetching weather data:', error);
      return null;
    }
  };

  const generateResponse = (places: Place[], query: string, queryInfo: any) => {
    if (places.length === 0) {
      const noResultsResponses = [
        "¡Buena pregunta! No encontré información específica sobre eso en mi base de datos. ¿Podrías ser más específico sobre qué buscás o en qué localidad?",
        "¡Entendido! No tengo ese dato específico en tiempo real. ¿Te gustaría que busque algo similar o en otra zona?",
        "¡Claro que sí! Aunque no tengo información exacta sobre eso, ¿querés que te ayude con alguna alternativa en la Comarca?"
      ];
      return noResultsResponses[Math.floor(Math.random() * noResultsResponses.length)];
    }

    // Identificar si hay lugares auspiciados (simulado por ahora)
    const hasSponsored = places.some(place => place.descripcion?.includes('destacado') || place.descripcion?.includes('recomendado'));
    
    const responses = [
      `¡Perfecto! Te encontré ${places.length} ${queryInfo.type === 'cabañas' ? 'cabañas' : 'lugares'} que te van a encantar${queryInfo.location ? ` en ${queryInfo.location}` : ''}.`,
      `¡Buenísimo! Aquí tenés ${hasSponsored ? 'nuestra recomendación especial y ' : ''}algunas excelentes opciones${queryInfo.type !== 'general' ? ` de ${queryInfo.type}` : ''}.`,
      `¡Claro que sí! Te comparto ${hasSponsored ? 'un lugar destacado y ' : ''}estas opciones que seguro te van a gustar${queryInfo.location ? ` en ${queryInfo.location}` : ''}.`
    ];

    // Agregar preguntas proactivas
    const proactiveQuestions = [
      " ¿Te gustaría que busque opciones para cenar también?",
      " ¿Necesitás saber cómo llegar a alguno?",
      " ¿Hay algo más en lo que pueda ayudarte para que tu día sea perfecto?",
      " ¿Querés que te recomiende actividades cerca de estos lugares?",
      ""
    ];

    const baseResponse = responses[Math.floor(Math.random() * responses.length)];
    const proactiveQuestion = proactiveQuestions[Math.floor(Math.random() * proactiveQuestions.length)];
    
    return baseResponse + proactiveQuestion;
  };

  const handleSendMessage = async () => {
    if (!input.trim()) return;

    // Verificar límite de uso
    if (!canUseFeature('chatAndes')) {
      toast({
        title: "Límite alcanzado",
        description: `Has usado tus ${getRemainingUses('chatAndes')} consultas diarias. Vuelve mañana.`,
        variant: "destructive",
      });
      return;
    }

    const userMessage: Message = {
      id: Date.now().toString(),
      text: input,
      sender: "user",
      timestamp: new Date()
    };

    updateMessages(prev => [...prev, userMessage]);
    const currentInput = input;
    setInput("");
    setIsLoading(true);

    try {
      // Manejar consultas sobre clima con el sistema anterior
      const queryInfo = analyzeQuery(currentInput);
      if (queryInfo.type === 'weather') {
        const weatherData = await getWeatherData(queryInfo.location);
        
        if (weatherData) {
          const { location, current, forecast } = weatherData;
          
          // Generar pronóstico por días
          const dailyForecasts = forecast.reduce((acc: any[], item: any) => {
            const dateStr = item.date.toLocaleDateString('es-AR', { weekday: 'long', day: 'numeric', month: 'long' });
            if (!acc.find(f => f.date === dateStr)) {
              acc.push({
                date: dateStr,
                temp: item.temp,
                temp_min: item.temp_min,
                temp_max: item.temp_max,
                description: item.description
              });
            }
            return acc;
          }, []);

          const weatherText = `🌤️ Clima en ${location}

📍 Ahora: ${current.temp}°C - ${current.description}
💨 Sensación térmica: ${current.feels_like}°C
💧 Humedad: ${current.humidity}%
🌬️ Viento: ${current.wind_speed} km/h

📅 Pronóstico para los próximos días:
${dailyForecasts.slice(0, 3).map((day: any) => 
  `• ${day.date}: ${day.temp_min}°C - ${day.temp_max}°C, ${day.description}`
).join('\n')}

¿Te gustaría saber el clima de otra localidad de la Comarca?`;

          const aiResponse: Message = {
            id: (Date.now() + 1).toString(),
            text: weatherText,
            sender: "ai",
            timestamp: new Date()
          };

          updateMessages(prev => [...prev, aiResponse]);
        } else {
          const aiResponse: Message = {
            id: (Date.now() + 1).toString(),
            text: "Disculpa, no pude obtener la información del clima en este momento. ¿Puedo ayudarte con algo más sobre la Comarca Andina?",
            sender: "ai",
            timestamp: new Date()
          };
          updateMessages(prev => [...prev, aiResponse]);
        }
        return;
      }

      // Usar Lovable AI para todas las demás consultas
      const functionUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/chat-andes`;
      
      const aiCallResponse = await fetch(functionUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ query: currentInput })
      });

      if (!aiCallResponse.ok) {
        if (aiCallResponse.status === 429) {
          toast({
            title: "Límite alcanzado",
            description: "Demasiadas consultas. Por favor, espera un momento.",
            variant: "destructive",
          });
          throw new Error("Rate limit");
        }
        if (aiCallResponse.status === 402) {
          toast({
            title: "Servicio temporalmente no disponible",
            description: "Por favor, contacta al administrador.",
            variant: "destructive",
          });
          throw new Error("Payment required");
        }
        throw new Error("Error en la consulta");
      }

      const aiData = await aiCallResponse.json();

      const aiResponse: Message = {
        id: (Date.now() + 1).toString(),
        text: aiData.response,
        sender: "ai",
        timestamp: new Date(),
        places: aiData.places && aiData.places.length > 0 ? aiData.places : undefined
      };

      updateMessages(prev => [...prev, aiResponse]);
      
      // Incrementar contador de uso solo si la consulta fue exitosa
      incrementUsage('chatAndes');
    } catch (error) {
      console.error('Error en chat:', error);
      if (error instanceof Error && (error.message === "Rate limit" || error.message === "Payment required")) {
        // Ya se mostró el toast, no agregar mensaje de error
      } else {
        const errorResponse: Message = {
          id: (Date.now() + 1).toString(),
          text: "Disculpa, hubo un problema al procesar tu consulta. Por favor intenta de nuevo.",
          sender: "ai",
          timestamp: new Date()
        };
        updateMessages(prev => [...prev, errorResponse]);
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleVoiceInput = () => {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
      const recognition = new SpeechRecognition();
      
      recognition.lang = 'es-AR';
      recognition.interimResults = false;
      recognition.maxAlternatives = 1;

      recognition.onstart = () => {
        setIsListening(true);
      };

      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setInput(transcript);
        setIsListening(false);
      };

      recognition.onerror = () => {
        setIsListening(false);
        toast({
          title: "Error de reconocimiento de voz",
          description: "No se pudo capturar el audio. Intenta de nuevo.",
          variant: "destructive",
        });
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognition.start();
    } else {
      toast({
        title: "Función no disponible",
        description: "El reconocimiento de voz no está disponible en este navegador.",
        variant: "destructive",
      });
    }
  };

  const suggestions = [
    "¿Dónde puedo comer en El Hoyo?",
    "Cabañas cerca del lago",
    "Actividades para hacer en familia", 
    "Hoteles en El Bolsón",
    "¿Cómo está el clima hoy?",
    "Lugares para visitar este fin de semana"
  ];

  if (selectedPlace) {
    return (
      <div className="fixed inset-0 z-50 bg-background overflow-auto">
        <div className="sticky top-0 bg-background border-b p-4 flex items-center gap-4 z-10">
          <Button variant="ghost" size="sm" onClick={() => setSelectedPlace(null)}>
            ← Volver al chat
          </Button>
        </div>
        <PlaceReviews placeId={selectedPlace.id} placeName={selectedPlace.name} />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <header className="bg-gradient-hero text-white p-4 shadow-lg">
        <div className="container mx-auto flex items-center gap-4">
          <Button 
            variant="ghost" 
            size="icon"
            onClick={onBack}
            className="text-white hover:bg-white/10"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div className="flex items-center gap-3">
            <Avatar className="bg-white/10">
              <AvatarFallback className="bg-transparent text-white">
                <Mountain className="w-5 h-5" />
              </AvatarFallback>
            </Avatar>
            <div>
              <h1 className="text-xl font-semibold">Andes</h1>
              <p className="text-sm text-white/80">Asistente de la Comarca</p>
            </div>
          </div>
        </div>
      </header>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-2 sm:p-4 custom-scrollbar">
        <div className="container mx-auto max-w-4xl space-y-3">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${message.sender === "user" ? "justify-end" : "justify-start"} px-1`}
            >
              <div className={`flex gap-2 sm:gap-3 w-full ${message.sender === "user" ? "max-w-[90%]" : "max-w-[95%]"} sm:max-w-[85%] ${message.sender === "user" ? "flex-row-reverse" : ""}`}>
                <Avatar className={`flex-shrink-0 w-8 h-8 sm:w-10 sm:h-10 ${message.sender === "ai" ? "bg-primary/10" : "bg-secondary"}`}>
                  <AvatarFallback>
                    {message.sender === "ai" ? (
                      <Mountain className="w-4 h-4 sm:w-5 sm:h-5 text-primary" />
                    ) : (
                      <User className="w-4 h-4 sm:w-5 sm:h-5" />
                    )}
                  </AvatarFallback>
                </Avatar>
                
                <div className={`flex flex-col w-full ${message.sender === "user" ? "items-end" : "items-start"}`}>
                  <Card className={`${message.sender === "user" ? "bg-primary text-primary-foreground" : "bg-card"} border-0 shadow-sm w-full max-w-full`}>
                    <CardContent className="p-3 sm:p-4">
                      {message.isSponsored && (
                        <Badge variant="outline" className="mb-2 text-xs">
                          Recomendación Destacada
                        </Badge>
                      )}
                      <p className="text-[15px] sm:text-base leading-relaxed whitespace-pre-line break-words">{message.text}</p>
                    
                      {message.imageUrl && (
                        <img 
                          src={message.imageUrl} 
                          alt="Lugar recomendado"
                          className="rounded-lg mt-3 w-full max-w-sm shadow-md"
                        />
                      )}
                      
                      {message.places && message.places.length > 0 && (
                        <div className="mt-4 space-y-3">
                          {message.places.map((place) => (
                            <div key={place.id} className={`p-3 sm:p-4 rounded-lg border ${place.es_auspiciante ? 'border-primary bg-primary/5' : 'border-border bg-background'}`}>
                              <div className="space-y-2 break-words">
                                <div className="flex items-start justify-between gap-2">
                                  <div className="flex-1 min-w-0">
                                    <h4 className="font-semibold text-sm sm:text-base flex items-center gap-2 flex-wrap">
                                      <span className="break-words">{place.nombre}</span>
                                      {place.es_auspiciante && (
                                        <Badge variant="default" className="text-xs flex-shrink-0">Destacado</Badge>
                                      )}
                                    </h4>
                                    <p className="text-xs sm:text-sm text-muted-foreground break-words">
                                      {place.tipo}{place.subtipo ? ` - ${place.subtipo}` : ''} • {place.localidad}
                                    </p>
                                  </div>
                                </div>
                                
                                {place.descripcion && (
                                  <p className="text-xs sm:text-sm break-words">{place.descripcion}</p>
                                )}
                                
                                {place.direccion && (
                                  <p className="text-xs text-muted-foreground break-words">📍 {place.direccion}</p>
                                )}
                                
                                {place.telefono && (
                                  <p className="text-xs text-muted-foreground break-words">📞 {place.telefono}</p>
                                )}
                                
                                <div className="flex flex-col sm:flex-row gap-2 pt-2">
                                  <Button 
                                    size="sm" 
                                    variant="outline" 
                                    className="text-xs w-full sm:flex-1"
                                    onClick={() => setSelectedPlace({ id: place.id, name: place.nombre })}
                                  >
                                    <Star className="w-3 h-3 mr-1 flex-shrink-0" />
                                    <span className="truncate">Ver valoración/opinar</span>
                                  </Button>
                                  <Button 
                                    size="sm" 
                                    variant="outline" 
                                    className="text-xs w-full sm:flex-1"
                                    onClick={() => {
                                      if (place.latitud && place.longitud) {
                                        onOpenMap({
                                          id: place.id,
                                          name: place.nombre,
                                          description: place.descripcion,
                                          latitude: Number(place.latitud),
                                          longitude: Number(place.longitud)
                                        });
                                      } else {
                                        toast({
                                          title: "Ubicación no disponible",
                                          description: "Este lugar no tiene coordenadas en el mapa",
                                          variant: "destructive"
                                        });
                                      }
                                    }}
                                  >
                                    <MapPin className="w-3 h-3 mr-1 flex-shrink-0" />
                                    <span className="truncate">Ver en el mapa</span>
                                  </Button>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                      
                      <div className="mt-2 text-xs text-muted-foreground">
                        {message.timestamp.toLocaleTimeString('es-AR', { 
                          hour: '2-digit', 
                          minute: '2-digit' 
                        })}
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </div>
          ))}
          
          {isLoading && (
            <div className="flex justify-start">
              <div className="flex gap-3 w-full max-w-[85%] sm:max-w-[80%]">
                <Avatar className="bg-primary/10">
                  <AvatarFallback>
                    <Mountain className="w-4 h-4 text-primary" />
                  </AvatarFallback>
                </Avatar>
                <Card className="bg-card border-0 shadow-md">
                  <CardContent className="p-4">
                    <div className="typing-indicator">
                      <span></span>
                      <span></span>
                      <span></span>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          )}
          
          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Suggestions */}
      {messages.length === 1 && (
        <div className="p-3 sm:p-4 border-t bg-muted/30">
          <div className="container mx-auto max-w-4xl">
            <p className="text-xs sm:text-sm text-muted-foreground mb-2 sm:mb-3">Sugerencias para empezar:</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:flex lg:flex-wrap gap-2">
              {suggestions.map((suggestion, index) => (
                <Button
                  key={index}
                  variant="outline"
                  size="sm"
                  className="text-xs w-full sm:w-auto justify-start sm:justify-center"
                  onClick={() => setInput(suggestion)}
                >
                  {suggestion}
                </Button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Input */}
      <div className="p-3 sm:p-4 border-t bg-background">
        <div className="container mx-auto max-w-4xl">
          <div className="flex gap-2">
            <div className="flex-1 flex gap-1 sm:gap-2">
              <Input
                placeholder="Pregúntale a Andes sobre la Comarca Andina..."
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
                disabled={isLoading}
                className="flex-1"
              />
              <Button
                size="icon"
                variant="outline"
                onClick={handleVoiceInput}
                disabled={isLoading}
                className={isListening ? "bg-primary text-primary-foreground" : ""}
              >
                {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
              </Button>
            </div>
            <Button 
              onClick={handleSendMessage} 
              disabled={!input.trim() || isLoading}
              className="bg-primary hover:bg-primary/90"
            >
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>

    </div>
  );
};