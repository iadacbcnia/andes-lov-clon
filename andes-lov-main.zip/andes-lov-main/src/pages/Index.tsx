import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { MapPin, MessageCircle, Calendar, Star, ArrowRight, Mountain, Camera, Map, Bot, Heart, Users, Shield, Sparkles, BookOpen } from "lucide-react";
import { useNavigate } from "react-router-dom";
import andesAvatar from "@/assets/andes-avatar.png";
import elBolsonImg from "@/assets/el-bolson.jpg";
import elHoyoImg from "@/assets/el-hoyo.jpg";
import lagoPueloImg from "@/assets/lago-puelo.jpg";
import epuyenImg from "@/assets/epuyen.jpg";
import cholilaImg from "@/assets/cholila.jpg";
import elMaitenImg from "@/assets/el-maiten.jpg";
import { ChatInterface } from "@/components/ChatInterface";
import { TripPlanner } from "@/components/TripPlanner";
import { InteractiveMap } from "@/components/InteractiveMap";
import { AdminPanel } from "@/components/AdminPanel";
import { MobileNav } from "@/components/MobileNav";
import { RadioPlayer } from "@/components/RadioPlayer";
import { AdminModeToggle } from "@/components/AdminModeToggle";

const Index = () => {
  const navigate = useNavigate();
  const [activeView, setActiveView] = useState<"home" | "chat" | "planner" | "map" | "admin">("home");
  const [previousView, setPreviousView] = useState<"home" | "chat" | "planner">("home");
  const [mapPlace, setMapPlace] = useState<{
    id: string;
    name: string;
    description?: string;
    latitude?: number;
    longitude?: number;
  } | null>(null);

  const [chatMessages, setChatMessages] = useState<any[] | undefined>(undefined);

  const destinations = [
    {
      name: "El Bolsón",
      description: "Pueblo artesanal rodeado de montañas",
      image: elBolsonImg,
      highlights: ["Feria Artesanal", "Cervecerías", "Trekking"]
    },
    {
      name: "El Hoyo",
      description: "Tranquilo pueblo entre montañas y bosques",
      image: elHoyoImg,
      highlights: ["Cerro Pirque", "Producción de Frutas", "Naturaleza"]
    },
    {
      name: "Lago Puelo",
      description: "Lago turquesa y Parque Nacional",
      image: lagoPueloImg,
      highlights: ["Parque Nacional", "Kayak", "Playas"]
    },
    {
      name: "Epuyén",
      description: "Pequeño pueblo con encanto rural",
      image: epuyenImg,
      highlights: ["Río Epuyén", "Pesca", "Vida Rural"]
    },
    {
      name: "Cholila",
      description: "Valle histórico y naturaleza salvaje",
      image: cholilaImg,
      highlights: ["Butch Cassidy", "Estancias", "Paisajes"]
    },
    {
      name: "El Maitén",
      description: "Pueblo ferroviario con historia",
      image: elMaitenImg,
      highlights: ["La Trochita", "Museo Ferroviario", "Historia"]
    }
  ];

  const features = [
    {
      icon: MessageCircle,
      title: "Asistente IA Andes",
      description: "Pregúntale sobre lugares, actividades y recomendaciones locales",
      action: () => setActiveView("chat")
    },
    {
      icon: Calendar,
      title: "Planificador Inteligente",
      description: "Crea tu itinerario perfecto con solo 4 preguntas",
      action: () => setActiveView("planner")
    },
    {
      icon: Map,
      title: "Mapa Interactivo",
      description: "Explora lugares con vista 360° y realidad aumentada",
      action: () => {
        setPreviousView("home");
        setActiveView("map");
      }
    },
    {
      icon: Sparkles,
      title: "Postal Mágica",
      description: "Transforma tus fotos con IA - Solo en la Comarca Andina",
      action: () => navigate("/postal-magica")
    },
    {
      icon: BookOpen,
      title: "Storybook con IA",
      description: "Crea un libro de recuerdos con tus fotos y la magia de Andes",
      action: () => navigate("/storybook")
    }
  ];

  if (activeView === "chat") {
    return <ChatInterface onBack={() => setActiveView("home")} onOpenMap={(place) => {
      setMapPlace(place);
      setPreviousView("chat");
      setActiveView("map");
    }} persistedMessages={chatMessages} onPersistMessages={setChatMessages} />;
  }

  if (activeView === "planner") {
    return <TripPlanner onBack={() => setActiveView("home")} />;
  }

  if (activeView === "map") {
    return <InteractiveMap 
      onBack={() => {
        setActiveView(previousView);
        setMapPlace(null);
      }} 
      selectedPlaceId={mapPlace?.id}
      selectedPlaceName={mapPlace?.name}
      selectedPlaceDescription={mapPlace?.description}
      selectedPlaceLatitude={mapPlace?.latitude}
      selectedPlaceLongitude={mapPlace?.longitude}
    />;
  }

  if (activeView === "admin") {
    return <AdminPanel onBack={() => setActiveView("home")} />;
  }

  return (
    <>
      <div className="min-h-screen bg-gradient-andes">
        {/* Mobile Navigation */}
        <MobileNav activeView={activeView} onViewChange={setActiveView} />

      {/* Desktop Radio Player - Fixed Position */}
      <div className="hidden lg:block fixed bottom-6 right-6 z-50">
        <RadioPlayer />
      </div>

      {/* About Andes Section - Moved to first */}
      <section className="py-20 bg-gradient-to-b from-background to-muted/30 relative overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          <div className="w-full h-full bg-primary/5 bg-[radial-gradient(circle_at_1px_1px,_hsl(var(--primary))_1px,_transparent_0)] bg-[length:30px_30px]" />
        </div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12 animate-fade-in">
              <h2 className="text-3xl md:text-4xl font-bold mb-4 bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                Conoce a Andes
              </h2>
              <p className="text-lg text-muted-foreground">
                Tu compañero inteligente para explorar la Comarca Andina
              </p>
            </div>
            
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              {/* Andes Avatar */}
              <div className="text-center lg:text-left animate-fade-in">
                <div className="relative inline-block">
                  <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-accent/20 rounded-full blur-3xl scale-150" />
                  <img 
                    src={andesAvatar} 
                    alt="Andes - Tu asistente turístico IA"
                    className="relative w-80 h-80 mx-auto rounded-full shadow-mountain object-cover border-4 border-white/10 backdrop-blur-sm"
                  />
                  <div className="absolute -bottom-4 -right-4 bg-gradient-to-br from-primary to-accent rounded-full p-3 shadow-lg">
                    <Bot className="w-6 h-6 text-white" />
                  </div>
                </div>
              </div>
              
              {/* About Content */}
              <div className="space-y-6 animate-fade-in" style={{ animationDelay: "0.2s" }}>
                <div className="space-y-4">
                  <h3 className="text-2xl font-bold">¡Hola! Soy Andes</h3>
                  <p className="text-lg text-muted-foreground leading-relaxed">
                    Soy tu asistente turístico inteligente, especializado en la hermosa Comarca Andina del Paralelo 42. 
                    Mi misión es hacer que tu experiencia en esta región mágica sea inolvidable.
                  </p>
                </div>
                
                <div className="grid gap-4">
                  <div className="flex items-start gap-3 p-4 bg-card/60 rounded-lg backdrop-blur-sm border border-primary/10">
                    <Heart className="w-5 h-5 text-primary mt-1 flex-shrink-0" />
                    <div>
                      <h4 className="font-semibold mb-1">Experto Local</h4>
                      <p className="text-sm text-muted-foreground">
                        Conozco cada rincón de El Bolsón, Lago Puelo, El Hoyo, Epuyén, Cholila y El Maitén.
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-3 p-4 bg-card/60 rounded-lg backdrop-blur-sm border border-primary/10">
                    <Users className="w-5 h-5 text-primary mt-1 flex-shrink-0" />
                    <div>
                      <h4 className="font-semibold mb-1">Personalizado</h4>
                      <p className="text-sm text-muted-foreground">
                        Adapto mis recomendaciones a tu estilo de viaje, presupuesto y preferencias únicas.
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-3 p-4 bg-card/60 rounded-lg backdrop-blur-sm border border-primary/10">
                    <Shield className="w-5 h-5 text-primary mt-1 flex-shrink-0" />
                    <div>
                      <h4 className="font-semibold mb-1">Confiable 24/7</h4>
                      <p className="text-sm text-muted-foreground">
                        Estoy disponible las 24 horas para responder tus preguntas y ayudarte en tu aventura.
                      </p>
                    </div>
                  </div>
                </div>
                
                <div className="pt-4">
                  <Button 
                    size="lg" 
                    className="bg-primary hover:bg-primary/90 text-white shadow-mountain"
                    onClick={() => setActiveView("chat")}
                  >
                    <MessageCircle className="mr-2 w-5 h-5" />
                    Comenzar a Chatear
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section - Moved to second */}
      <section className="py-20 bg-background relative">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-background/50 to-transparent" />
        <div className="container mx-auto px-4 relative z-10">
          <div className="text-center mb-16 animate-fade-in">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
              Explora como nunca antes
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Tecnología avanzada para conectarte con la naturaleza patagónica
            </p>
          </div>
          
          <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-8">
            {features.map((feature, index) => (
              <Card 
                key={index} 
                className="group cursor-pointer hover:shadow-mountain transition-all duration-500 hover:-translate-y-3 hover:scale-105 border-0 bg-card/60 backdrop-blur-md animate-fade-in"
                style={{ animationDelay: `${index * 0.1}s` }}
                onClick={feature.action}
              >
                <CardHeader className="text-center">
                  <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-primary/10 to-accent/10 rounded-full mb-4 mx-auto group-hover:from-primary/20 group-hover:to-accent/20 transition-all duration-300 group-hover:shadow-glow">
                    <feature.icon className="w-8 h-8 text-primary group-hover:scale-110 transition-transform duration-300" />
                  </div>
                  <CardTitle className="text-xl group-hover:text-primary transition-colors">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground text-center">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Hero Section - Moved to third */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-16 md:pt-0">
        <div className="absolute inset-0 bg-black/20" />
        <div className="container mx-auto px-4 text-center relative z-10">
          <div className="animate-fade-in">
            <div className="inline-flex items-center justify-center w-20 h-20 bg-primary/10 rounded-full mb-8 animate-mountain-float">
              <Mountain className="w-10 h-10 text-primary" />
            </div>
            <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 drop-shadow-lg">
              Andes
            </h1>
            <p className="text-xl md:text-2xl text-white/90 mb-8 max-w-2xl mx-auto">
              Tu guía experto en el Paralelo 42
            </p>
            <p className="text-lg text-white/80 mb-12 max-w-xl mx-auto">
              Descubre la magia de la Comarca Andina con nuestro asistente inteligente
            </p>
            <Button 
              size="lg" 
              className="bg-primary hover:bg-primary/90 text-white px-8 py-6 text-lg rounded-full shadow-mountain animate-pulse-glow"
              onClick={() => setActiveView("chat")}
            >
              Comenzar Aventura
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
          </div>
        </div>
      </section>

      {/* Destinations Section */}
      <section className="py-20 bg-gradient-to-b from-muted/30 to-background relative overflow-hidden">
        <div className="absolute inset-0 opacity-40">
          <div className="w-full h-full bg-primary/5 bg-[radial-gradient(circle_at_1px_1px,_hsl(var(--primary))_1px,_transparent_0)] bg-[length:20px_20px]" />
        </div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="text-center mb-16 animate-fade-in">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
              Pueblos de la Comarca Andina
            </h2>
            <p className="text-lg text-muted-foreground">
              Descubre los encantadores pueblos del Paralelo 42
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {destinations.map((destination, index) => (
              <Card 
                key={index} 
                className="group overflow-hidden border-0 shadow-lg hover:shadow-mountain transition-all duration-500 hover:-translate-y-2 hover:scale-105 animate-fade-in bg-card/80 backdrop-blur-sm"
                style={{ animationDelay: `${index * 0.2}s` }}
              >
                <div className="relative h-48 overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent z-10" />
                  <img 
                    src={destination.image} 
                    alt={destination.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute top-4 right-4 z-20">
                    <Badge variant="secondary" className="bg-white/95 text-foreground shadow-md backdrop-blur-sm">
                      <MapPin className="w-3 h-3 mr-1" />
                      Comarca Andina
                    </Badge>
                  </div>
                </div>
                <CardContent className="p-6">
                  <h3 className="text-xl font-semibold mb-2">{destination.name}</h3>
                  <p className="text-muted-foreground mb-4">{destination.description}</p>
                  <div className="flex flex-wrap gap-2">
                    {destination.highlights.map((highlight, highlightIndex) => (
                      <Badge key={highlightIndex} variant="outline" className="text-xs">
                        {highlight}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-hero text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            ¿Listo para tu próxima aventura?
          </h2>
          <p className="text-xl mb-8 text-white/90 max-w-2xl mx-auto">
            Deja que Andes te guíe por los senderos más hermosos de la Patagonia
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <Button 
                size="lg" 
                variant="secondary"
                className="bg-white/10 hover:bg-white/20 text-white border-white/20 backdrop-blur-sm"
                onClick={() => setActiveView("planner")}
              >
                <Calendar className="mr-2 w-5 h-5" />
                Planificar Viaje
              </Button>
              <Button 
                size="lg" 
                variant="outline"
                className="bg-transparent hover:bg-white/10 text-white border-white/30"
                onClick={() => setActiveView("chat")}
              >
                <MessageCircle className="mr-2 w-5 h-5" />
                Hablar con Andes
              </Button>
            </div>
          </div>
        </section>

        {/* Admin Access - Hidden link */}
        <div className="fixed bottom-4 left-4 md:bottom-4 md:left-4 z-50">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setActiveView("admin")}
            className="opacity-30 hover:opacity-100 transition-opacity text-xs bg-black/20 hover:bg-black/40"
          >
            🔐 Admin
          </Button>
        </div>
        
        {/* Admin Mode Toggle */}
        <AdminModeToggle />
      </div>
      
      {/* Admin Mode Toggle */}
      <AdminModeToggle />
    </>
  );
};

export default Index;